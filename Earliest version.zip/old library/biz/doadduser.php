<?php
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php'; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Information added</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<script language='javascript'>
function checksignup() {
if ( document.addform.xyname.value == '' ) {
window.alert('Please enter username^_^');
document.addform.xyname.focus();
return false;}

if ( document.addform.uPass.value == '' || document.addform.re_uPass.value =='' ) {
window.alert('Please enter password^_^');
document.addform.uPass.focus();
return false;}

return true;}
</script>
</head>
<body >
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageuser.php">User Management</a>| <a href="doadduser.php">Add user</a>
    </ul>
  </div>
  <script>
	//|str_replace=.'/index.php','',###
	var onurl ='doadduser.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
	</script>
  <div id="msg"></div>
  <form name="addform" id="addform" action="?act=ok" method="post">
    <table cellpadding=0 cellspacing=0 class="table_form" width="100%">
      <tr>
        <td width="10%" >Username</td>
        <td width="90%" >
          <input type="text" class="input-text" name="uName"  id="title"  size="55" /> 
		  <font color="red">*</font>
          </td>
      </tr>
      <tr>
        <td width="10%" >Type</td>
        <td width="90%" >
         <input type="radio" name="uKind" value="0" checked>Anonymous user
         <input type="radio" name="uKind" value="1">Administrator
          </td>
      </tr>
      <tr>
        <td width="10%" >Password</td>
        <td width="90%"><input type="text" name="uPass" class="input-text" size="55" /> 
		<font color="red">*</font></td>
      </tr>
      <tr>
        <td width="10%" >Confirm Password</td>
        <td width="90%" ><input type="text" name="reuPass" class="input-text" size="55" /></td>
      </tr> 
      <tr>
        <td width="10%" >ID No.:</td>
        <td width="90%" ><input type="text" name="card_no" class="input-text" size="55" /></td>
      </tr> 
      <tr>
        <td width="10%" >Phone:</td>
        <td width="90%" ><input type="text" name="tel" class="input-text" size="55" /></td>
      </tr>
      <tr>
        <td width="10%" >Address:</td>
        <td width="90%" ><input type="text" name="address" class="input-text" size="55" /></td>
      </tr> 
    </table>
    <div id="bootline"></div>
    <div id="btnbox" class="btn">
      <INPUT TYPE="submit"  value="Submit" class="button" onClick='javascript:return checksignup()'>
      <input TYPE="reset"  value="Cancel" class="button"><input TYPE="hidden"  name="act" value="ok" class="button">
    </div>
  </form>
</div>
</body>
</html>
<?php

if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	$uName = $_POST["uName"];
	$uPass = $_POST["uPass"];
	$reuPass = $_POST["reuPass"];
	$card_no = $_POST["card_no"];
	$tel = $_POST["tel"];
	$address = $_POST["address"];
	if(empty($uName)){
		echo "<script> alert('Please enter username');location='doadduser.php'; </script>";
	}elseif(empty($uPass)){
		echo "<script> alert('Please enter password');location='doadduser.php'; </script>";
	}elseif(empty($reuPass)){
		echo "<script> alert('Please enter confirmation password');location='doadduser.php'; </script>";
	}elseif($reuPass!=$uPass){
		echo "<script> alert('The password entered twice does not match!');location='doadduser.php'; </script>";
	}elseif(empty($card_no)){
		echo "<script> alert('ID number cannot be empty');location='doadduser.php';  </script>";
	}elseif(empty($tel)){
		echo "<script> alert('Phone number cannot be empty');location='doadduser.php';  </script>";
	}elseif(empty($address)){
		echo "<script> alert('Contact address cannot be empty');location='doadduser.php';  </script>";
	}else{
		$curUser =  findUserinfoByName($uName);	
		if($curUser){
			echo "<script> alert('This username already exists!');location='doadduser.php';  </script>";
		}else{
			$ret =  addUserinfo($uName, $uPass, $ukind, $address, $card_no, $tel);
			if($ret){
				echo "<script> alert('Add successfully');location='domanageuser.php';  </script>";
			}
		}
	}
}
?>