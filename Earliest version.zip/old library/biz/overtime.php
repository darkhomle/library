<?php
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php';
require_once '../dao/productsinfoDao.php';
require_once '../dao/cartDao.php';

if(isset($_GET['cartID'])&&!empty($_GET['cartID'])){
	$result = ReturnCart($_GET['cartID']);
	$result = setPorductNum($_GET['productID'],2);
	if($result){
		echo "<script> alert('Successful return
');windows.location.href='./domanageorder.php'; </script>";
	}
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<title>Administrator Management</title>
<script language="javascript">
function ask(msg) {
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body>
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="overtime.php">Overtime charge management</a><span style="color:red;">If a book is not returned for more than 20 days, an additional charge of RMB 10 per day will be applied.</span>
    </ul>
    <div class="clear"></div>
  </div>
  
  <form name="addform" action="" method="post">
    <div class="table-list">
      <table width="100%" cellspacing="0">
        <thead>
          <tr>
            <th width="40">id</th>
            <th width="30">Picture</th>
			 <th width="230">Book</th>
			 <th width="45">Number</th>
			 <th width="105">Borrower</th>
			 <th width="105">Status</th>
			 <th width="125">Time</th>
			 <th  width="105">Fees</th>
          </tr>
        </thead>
        <tbody>
<?php
    $resultporduct = findovertime();
    if(!empty($resultporduct)){
	foreach($resultporduct as $k=>$v){
		
		$Productinfo = findProductinfoById($v['productID']);
		$Userinfo = findUserinfoById($v['userID']);
	    $flag = ($v['flag']==1)?'On loan':'Returned';
		
		
		?>
		<tr>
		 <td><?php echo $v['cartID'];?></td>
		 <td><img src="./upload/<?php echo $Productinfo['image'];?>" width="35" height="35" style="border:1px solid #ccc;padding:1px;" /></td>
		 <td><?php echo $Productinfo['productName'];?> </td>
		 <td><?php echo $Productinfo['num'];?></td>
		 <td><?php echo $Userinfo['uName'];?></td>
		 <td><?php echo $flag;?></td>
		 <td><?php 
		 echo 'Loan：'.date('Y/m/d',strtotime($v['c_date']));
		 echo '<br>';
		 if($v['u_date']!='0000-00-00 00:00:00'){
			  echo 'Return：'.date('Y/m/d',strtotime($v['u_date']));
		 }
		 //借阅超时
		 $diff_d = (time()-strtotime($v['c_date']))/86400;
		 $diff_d = round($diff_d);
		 $diff2= $diff_d-20;
		 echo 'Already <font color=red>'.$diff_d.'</font> Days yet to return'; 
		 if($diff2>=1){
			echo '(Overdue <font color=red><b>'.$diff2.'</b></font> Days)';
		 }
		 ?></td>
		 <td>
		 <?php 
		   if($v['flag']==1&&$diff2>=1){
				echo ($diff2*10).'Yuan';
		   }?>
		
		</td>
		</tr>
	<?php } 
	}else{?>
		<tr><td colspan="6">No suitable data is available at the moment!  </td></tr>
	<?php }?>
     </tbody>
      </table>
    </div>
  </form>
</div>
</body>
</html>
