<?php 
require_once './dao/globle.inc.php';
require_once './dao/productsinfoDao.php';
require_once './dao/producttypeDao.php';
$search = '';
if(isset($_POST['search'])&&!empty($_POST['search'])){
	$search = $_POST['search'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
$(function(){
	$("#kinMaxShow").kinMaxShow();
});
</script>
<style>
.search_btn_collect{
	width: 134px;
    height: 30px;
    line-height: 28px;
    background: #ffedee;
    color: #ff2832;
    border: 1px solid #ff2832;
    display: inline-block;
    *display: inline;
    zoom: 1;
    border-radius: 3px;
    text-align: center;
    font-family: 'Microsoft Yahei';
    font-size: 14px;
	margin-right: 10px;
}
.search_btn_collect2{
	width: 134px;
    height: 30px;
    line-height: 28px;
    background: #CCE8FF;
    color: #32869E;
    border: 1px solid #32869E;
    display: inline-block;
    *display: inline;
    zoom: 1;
    border-radius: 3px;
    text-align: center;
    font-family: 'Microsoft Yahei';
    font-size: 14px;
	margin-right: 10px;
}
</style>
</head>

<body>
 <div class="mianCont">
  <div class="top">
  <?php echo login_top();?>
  <div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="index.php" method="post" class="subBox" name="search" id="search">
    <div class="subBoxDiv">
     <input type="text" name="search" class="subLeft" value="<?php echo $search;?>" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" onclick="('#search').submit();" />
     <div class="hotWord">
      Popular searches: 
      <a href="#"> Children's books</a>&nbsp;
      <a href="#">Masterpieces</a> &nbsp;
      <a href="#">Literature</a>&nbsp;
     </div><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title"><a href="index.php">All book categories</a></h2>
    <ul class="InPorNav">
    <?php $result = findProductTypeAll();
        foreach($result as $k=>$row){
			echo '<li><a href="index.php?typeID='.$row['typeID'].'">'.$row['typeName'].'</a></li>';
		}
	?>
    </ul><!--InPorNav/-->
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
     <li><a href="biz/index.php">Administrator</a></li>
     <div class="clears"></div>
     <div class="phone">TEL：010-12345678</div>
    </ul><!--nav/-->
    <div class="banner">
     <div id="kinMaxShow">
      <div>
       <a href="#"><img src="images/ban5.png" height="360"  /></a>
      </div> 		
      <div>
       <a href="#"><img src="images/ban6.png" height="360"  /></a>
      </div>
      <div>
       <a href="#"><img src="images/ban7.png" height="360"  /></a>
      </div>
      <div>
       <a href="#"><img src="images/ban8.png" height="360"  /></a>
      </div>     
     </div><!--kinMaxShow/-->
    </div><!--banner/-->
	
   </div><!--pntRight/-->
   <div class="clears"></div>
   
	<div class="floor" id="floor2">
	<div class="H2t">Book List</div>
    <div class="floorBox"><!--floorLeft/-->
    <div class="floorRight">
    <div class="frProList">
	<?php
	if(isset($_GET['typeID'])&&$_GET['typeID']!=''){
		
		$resultporduct = findAllproductinfoByTypeID($_GET['typeID'],$search);
	}else{
		
		$resultporduct = findAllproductinfo(0,$search);
	}
		
	foreach($resultporduct as $k=>$v){?>
		<dl>
		<dt><a href="proinfo.php?productID=<?php echo $v['productID'];?>">
		<img src="./biz/upload/<?php echo $v['image'];?>" width="132" height="129" /></a></dt>
		<dd style="height:40px"><span class="H3t" style="font-size:14px;line-height:18px;"><?php echo $v['productName'];?></span></dd>
		<dd class="cheng">
		 <?php if($v['num']>0){?>
		<form action="proinfo.php" method="post" name="proinfo">
			<input type="hidden" name="act" value="ok"/>
			<input type="submit" name="buy" value="Loan（<?php echo $v['num'];?> Books）" class="search_btn_collect"/>
			<input type="hidden" name="productID" value="<?php echo $v['productID'];?>"/>
	    </form>
		 <?php }else{?>
		<form action="proinfo.php" method="post" name="proinfo2">
			<input type="hidden" name="act" value="ok2"/>
			<input type="submit" name="buy" value="reserve（<?php echo $v['num'];?> Books）" class="search_btn_collect2"/>
			<input type="hidden" name="productID" value="<?php echo $v['productID'];?>"/>
	    </form>
		 <?php  }?>
		</dd>
		</dl>
	<?php } ?>
    
    <div class="clears"></div>
      
    </dl>
      <div class="clears"></div>
     </div><!--frProList-->
    </div><!--floorRight/-->
    <div class="clears"></div>
 </div><!--floorBox/-->
  </div><!--floor/--><!--inHelp/-->
  </div><!--pnt/--><!--rdPro/--><!--hengfu/--><!--floor/--><!--hengfu/--><!--floor/-->
  <div class="hengfu"></div><!--hengfu/-->
  
 <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
</body>
</html>
