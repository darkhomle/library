<title>Library Loan Management System</title> <div class="footer">
   <p>&nbsp;</p>
   <p>Copyright © <?php echo date('Y');?> Design by Library Loan Management System</p>
  </div><!--footer/-->