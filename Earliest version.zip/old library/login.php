<?php 
require_once './dao/userDao.php';
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	//从表单中读取登录信息
	$uName = $_POST["uName"];
	$uPass = $_POST["uPass"]; 

	$curUser =  findUserinfoByNamePwd($uName,$uPass);
	if (count($curUser) > 0){
			
			$_SESSION["CURRENT_USER"] = $curUser;
			$_SESSION["CURRENT_USER_OK"] = 1;
			echo "<script> alert('Login success');parent.location.href='./index.php'; </script>";
			//header("location:./index.php");
	}else{
		echo "<script> alert('Incorrect account or password!');parent.location.href='./login.php'; </script>";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
	<link rel="stylesheet" href="./biz/style/reset.css" />
	<link rel="stylesheet" href="./biz/style/login.css" />
</head>
<body>
<div class="page">
	<div class="loginwarrp">
	  <div class="login_form"><p style="width:100%;text-align:center;font-size:20px;color:rgb(69, 181, 73);">Login</p>
            <form id="Login" name="Login" method="post" onSubmit="" action="">
				<li class="login-item">
					<span>User:</span>
					<input type="text" name="uName" class="login_input">
				</li>
				<li class="login-item">
					<span>PIN:</span>
					<input type="password" name="uPass" class="login_input">
				<div class="clearfix">
				<li class="login-sub"> <input TYPE="hidden" value="ok" name="act" class="button">
                                    <input type="submit" name="Submit" value="Login" /><a href="index.php" >[Back to Home]</a></li>
                                   </div>             
           </form>
		</div>
	</div>
</div>
</body>
</html>