<?php 
require_once './dao/globle.inc.php';
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
 <div class="mianCont">
  <div class="top">
   <?php echo login_top();?>
  <div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="#" method="get" class="subBox">
    <div class="subBoxDiv">
     <input type="text" class="subLeft" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" /><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
    </ul><!--InPorNav/-->
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
      <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
     <li><a href="biz/index.php">Add books</a></li>
     <div class="clears"></div>
     <div class="phone">TEL：010-12345678</div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
   Current position: <a href="index.php">Home</a> &gt; <a href="#" class="posCur">Loan</a>
  </div><!--positions/-->
  <div class="cont">
   <div class="chenggong">
    <h3>Borrow Success</h3>
	 <a href="./index.php" class="jie_2">Back to home&gt;&gt;</a>
   </div><!--chenggong/-->
  </div><!--cont/--><!--inHelp/-->
 <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
</body>
</html>
