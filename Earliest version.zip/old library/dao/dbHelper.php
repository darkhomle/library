﻿<?php 
error_reporting(0);
//开启会话
session_start();

//创建数据库连接
function getConn() {
    $conn = @mysqli_connect("localhost", "root", "", "bookshops") or die(header("location:../error.php?msg='Database connection failed'"));
    mysqli_query($conn, "set names utf8");
  return $conn;
}

//执行insert、update、delete
function execUpdate($sql) {
    $conn = getConn();
    $result = @mysqli_query($conn, $sql);
    mysqli_close($conn);
    return $result;
}

//执行select,返回二维数组
function execQueryAll($sql) {
    $conn = getConn();
    $result = array();
    $rs = @mysqli_query($conn, $sql);
    //处理结果集
    for ($i = 0; $i < mysqli_num_rows($rs); $i++) {
        $result[$i] = mysqli_fetch_assoc($rs);
    }
    //释放结果集
    mysqli_free_result($rs);
    //关闭连接
    mysqli_close($conn);
    return $result; //二维数组
}

//执行select,返回一维数组
function execQueryOne($sql) {
    $resultOne = array();
    $results = execQueryAll($sql);
    if (count($results) > 0) {
        $resultOne = $results[0];
    }
    return $resultOne;
}
?>

