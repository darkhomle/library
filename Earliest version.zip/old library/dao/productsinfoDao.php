<?php
require_once 'dbHelper.php';
//查询所有图书，返回二维数组
function findAllproductinfo($upUserID=0,$search=null){
	if(empty($search)){
		$where  = '1=1';
	}else{
		$where = "productName like '%{$search}%'";
	}
	if($upUserID!=0){
		$where.= " and upUserID ='{$upUserID}'";
	}
	$sql="select * from tblproducts where ".$where;

	return execQueryAll($sql);
}
//按分类查询所有图书，返回二维数组
function findAllproductinfoByTypeID($typeID,$search=null){
	if(empty($search)){
		$where  = '';
	}else{
		$where = " AND productName like '%{$search}%'";
	}
	$sql="select * from tblproducts where typeID='$typeID' {$where}";

	return execQueryAll($sql);
}
     
//根据图书名称查询图书信息，返回二维数组
function searchProductinfoByName($upUserID,$productName,$type=''){
	if($type==1){
		$w = "productName like '%$productName%'";
	}else{
		$w = "zuozhe like '%$productName%'";
	}
	$sql="select * from tblproducts where {$w}";
	if($upUserID!=0){
		$sql.= " and upUserID ='{$upUserID}'";
	}
	
	return execQueryAll($sql);
}
     
//根据图书名称查询图书信息，返回二维数组
function findProductinfoByName($productName){
	$sql="select * from tblproducts where productName=$productName";
	return execQueryAll($sql);
}
//根据图书ID查询图书信息,返回一维数组
function findProductinfoById($productID){
	$sql="select * from tblproducts where productID=$productID";

	return execQueryOne($sql);
}

//添加类型名称
function addProduct($upUserID,$typeID,$productName,$price,$num,$image,$detail,$zuozhe,$chubanshe){
	//$sql="insert into tblproducts values(null,'$upUserID','$typeID','$productName','$price','$num','$detail','$image')";
	$sql="INSERT INTO `tblproducts` ( `upUserID`, `typeID`, `productName`, `price`, `num`, `detail`, `chubanshe`, `zuozhe`, `image`) 
	VALUES ( '{$upUserID}', '{$typeID}', '{$productName}', '{$price}', '{$num}', '{$detail}', '{$chubanshe}', '{$zuozhe}', '{$image}');";
	
	return execUpdate($sql);
}
//编辑类型名称
function updateProductNum($productID){

    $sql="update tblproducts set num=num-1 where productID=$productID";
    return execUpdate($sql);
}
//编辑类型名称
function updateProductFile($file,$productID){
    $sql="update tblproducts set file='$file'where productID=$productID";
    return execUpdate($sql);
}
//编辑类型名称
function updateProduct($typeID,$productName,$price,$num,$image,$detail,$zuozhe,$chubanshe,$productID){
	$i = "";
	if(!empty($image)){
		$i = ",image='{$image}'";
	}
    $sql="update tblproducts set productName='$productName'
	,typeID='$typeID'
	,price='$price'
	,num='$num'
	,zuozhe='$zuozhe'
	,chubanshe='$chubanshe'
	{$i}
	,detail='$detail'
	where productID=$productID";

    return execUpdate($sql);
}
//编辑类型名称
function updateProduct2($typeID,$productName,$price,$num,$detail,$productID){

    $sql="update tblproducts set productName='$productName'
	,typeID='$typeID'
	,price='$price'
	,num='$num'
	,detail='$detail'
	where productID=$productID";
    return execUpdate($sql);
}
//删除类型名称
function deleteProduct($productID){
    $sql="delete from tblproducts where productID='$productID'";
    return execUpdate($sql);
}
  