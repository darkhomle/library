<?php
require_once 'dbHelper.php';
//根据用户ID查询借阅信息,返回一维数组 
function findOrderInfoById($orderID){
    $sql="select *from tblorderinfo where orderID='$orderID'";
    return execQueryOne($sql);
}
function findOrderInfos(){
    $sql="select *from tblorderinfo where 1=1";
	if(isset($_SESSION['loginuser']['uKind'])&&$_SESSION['loginuser']['uKind']!=1){
		$sql2="select productID from tblproducts where upUserID='{$_SESSION['loginuser']['uID']}'";
		$result2 = execQueryAll($sql2);
		$tmp = array();
		foreach($result2 as $k=>$v){
			$tmp[]=$v['productID'];
		}
		$ids = implode(",",$tmp);	
		$sql.=" and productID  in ('{$ids}')";
	}
	
    return execQueryAll($sql);
}
function findOrderInfosByUserID($UserID){
    $sql="select *from tblorderinfo where UserID='$UserID'";
    return execQueryAll($sql);
}

//添加借阅信息
function addOrderinfo($userId,$productID,$quantity,$totalPrice){
    $sql="insert into tblorderinfo  values(null,'$userId','$productID','$quantity','$totalPrice')";
    return execUpdate($sql);
}
//借阅信息删除
function delOrderinfo($orderID){
    $sql="delete from `tblorderinfo` WHERE orderID=$orderID";
    return execUpdate($sql);
}



