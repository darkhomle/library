<?php
require_once 'dbHelper.php';
//根据用户名查询用户信息，返回一维数组
function findUserInfos(){
    $sql="select *from tbluser where 1=1";
	if(isset($_SESSION['loginuser']['uKind'])&&$_SESSION['loginuser']['uKind']!=1){
		 $sql.=" and uID='{$_SESSION['loginuser']['uID']}'";
	}
    return execQueryAll($sql);
}
//根据用户名查询用户信息，返回一维数组 
function findUserinfoByName($uName){
    $sql="select * from tbluser  where uName='$uName'";
        return execQueryOne($sql);
}
//根据身份证号查询用户信息，返回一维数组 
function findUserinfoByCard($card_no){
    $sql="select * from tbluser  where card_no='$card_no'";
        return execQueryOne($sql);
}
//根据用户名查询用户信息，返回一维数组 
function findUserinfoByNameID($uName,$uID){
    $sql="select * from tbluser  where uName='$uName' and uID!='$uID'";
    return execQueryOne($sql);
}
//根据用户名查询用户信息，返回一维数组 
function findUserinfoByNamePwd($uName,$uPass){
    $sql="select * from tbluser  where uName='$uName' and uPass='$uPass'";
    return execQueryOne($sql);
}
//根据用户id查询用户密码，返回一维数组 
function findUserinfoByuIDPwd($uID,$uPass){
    $sql="select * from tbluser  where  uID='$uID' and uPass='$uPass'";
    return execQueryOne($sql);
}
//根据用户编号id查询用户信息，返回一维数组
function findUserinfoById($uId){
	$sql="select * from tbluser where uId=$uId";	
	return execQueryOne($sql);
}
//添加用户信息
function addUserinfo($uName, $uPass, $ukind, $address, $card_no, $tel){
    $sql="INSERT INTO `tbluser` ( `uName`, `uPass`, `uKind`, `address`, `card_no`, `tel`) 
	VALUES ('{$uName}', '{$uPass}', '{$uKind}', '{$address}', '{$card_no}', '{$tel}');";
	
    return execUpdate($sql);
    
}
//修改用户信息
function updateUserinfo($uName, $uPass,$uKind, $address,$card_no,$tel, $uId){
    $sql="update tbluser set uName='$uName',uPass='$uPass',uKind='$uKind'
	,address='$address',card_no='$card_no',tel='$tel' 
	where uId=$uId";
	
    return execUpdate($sql);
}
//修改用户密码
function updateUserPassword($uPass, $uId){
    $sql="update tbluser set uPass='$uPass'
	where uId=$uId";
	
    return execUpdate($sql);
}
//修改用户信息
function updateUserinfo2($uName, $uId){
    $sql="update tbluser set uName='$uName' where uId=$uId";
    return execUpdate($sql);
}
//删除用户信息
function deleteUserinfo($uId){
    $sql="delete from tbluser where uId='$uId'";
    return execUpdate($sql);
}

?>