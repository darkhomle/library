<?php 
require_once './dao/globle.inc.php';
require_once './dao/productsinfoDao.php';
require_once './dao/producttypeDao.php';
require_once './dao/cartDao.php';
require_once './dao/orderinfoDao.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
 <div class="mianCont">
  <div class="top">
  <?php echo login_top();?>
  <div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="#" method="get" class="subBox">
    <div class="subBoxDiv">
     <input type="text" class="subLeft" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" /><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
     <ul class="InPorNav">
    
    </ul><!--InPorNav/-->
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
      <li><a href="biz/index.php">Add books</a></li>
     <div class="clears"></div>
     <div class="phone">TEL：010-12345678</div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
   Current position: <a href="#" class="posCur">My Loans</a>
  </div><!--positions/-->
  <div class="cont">
   
	 <input type="hidden" value="" name="type" id="type"/>
    <table class="orderList">
    <tr>
     <th width="30">Picture</th>
     <th width="430">Book</th>
     <th width="135">Number</th>
     <th width="135">Price</th>
    
    </tr>
	<?php 
	$userID = $_SESSION["CURRENT_USER"]['uID'];
	$resultporduct = findOrderInfosByUserID($userID);
	$total_price = 0;
	if(!empty($resultporduct)){
	foreach($resultporduct as $k=>$v){
		$Productinfo = findProductinfoById($v['productID']);
		$total_price = $total_price+$v['totalPrice'];
		?>
    <tr>
    
     <td><img src="./biz/upload/<?php echo $Productinfo['image'];?>" width="85" height="85" style="border:1px solid #ccc;padding:1px;" /></td>
	 <td><?php echo $Productinfo['productName'];?> </td>
     <td>1
     <!--div class="jia_jian">
      <img src="images/jian.jpg" width="21" height="25" class="jian" />
      <input type="text" class="shuliang" value="1" />
      <img src="images/jia.jpg" width="21" height="25" class="jia" />
     </div-->
     </td>
     <td>￥<?php echo $v['totalPrice'];?></td>
    
    </tr>
    <?php }
	}else{?>
		<tr><td colspan="4">No suitable data available at the moment! </td></tr>
	<?php } ?>
   
   </table><!--orderList/-->
   <div class="zongji">
    Total: <strong class="red">￥<?php echo $total_price;?></strong>
   </div><!--zongji/-->
  
   </form>
   <!--jiesuan/-->
   <div class="clears"></div>
  </div><!--cont/--><!--inHelp/-->
 <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
 <script>
 function carsubmit(type){
	document.getElementById("type").value=type;
	document.getElementById("myForm").submit()
 }
 </script>
</body>
</html>
