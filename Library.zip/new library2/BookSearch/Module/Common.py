# -*- coding: utf-8 -*-sts
import pandas as pd
import numpy as np
import os
import base64
from io import BytesIO
from PIL import Image

#当前目录
curDir = os.path.dirname(os.path.abspath(__file__))
#根目录
baseDir = os.path.dirname(curDir)
#静态文件目录
staticDir = os.path.join(baseDir,'Static')
#结果文件目录
resultDir = os.path.join(baseDir,'Result')


def array2base64(matrix):
    '''将numpy矩阵转为base64'''
    #bgr -> rgb
    matrix = matrix[...,[2,1,0]]
    pilImg = Image.fromarray(matrix)
    buff = BytesIO()
    pilImg.save(buff, format="PNG")
    matrix = str(base64.b64encode(buff.getvalue()), encoding='utf-8')
    matrix = "data:image/png;base64," + matrix
    return matrix