from django.shortcuts import render_to_response
from django.http import JsonResponse
from django.conf import settings
from BookSearch import *
from Module.Common import *
import base64
import os

def bookSearch(request):
    '''图书查找的api，上传图片base64编码'''
    imgBase64 = request.POST["imgBase64"]#获得客户上传的图片base64
    imgBase64 = imgBase64.split("base64,")[1]
    with open(staticDir+"/tmp.png", 'wb') as f:
        f.write(base64.b64decode(imgBase64))
    #遍历所有书籍图片集
    maxSim = 0
    paths = os.listdir(staticDir+"/Book Image")
    for path in paths:
        name = path.split('.')[0]#书名
        #计算相似度
        print(path)
        sim, markImg1, boxImg1, markImg2, boxImg2 = compareTwoImageByPath(staticDir+"/tmp.png",staticDir+"/Book Image/"+path)
        #保存最佳匹配结果
        if sim>maxSim:
            maxSim = sim
            markImg1 = array2base64(markImg1)
            boxImg1 = array2base64(boxImg1)
            boxImg2 = array2base64(boxImg2)
            bestResult = [float(sim), markImg1, boxImg1, boxImg2,name]
    result = {"sim":bestResult[0],"markImg":str(bestResult[1]),"boxImg":str(bestResult[2]),"targetImg":str(bestResult[3]),"name":str(bestResult[4])}
    return JsonResponse(result)
