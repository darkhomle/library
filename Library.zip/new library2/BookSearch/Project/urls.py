from django.contrib import admin
from django.urls import path,include
from django.views.generic.base import RedirectView
from .views import *
urlpatterns = [
    path('admin/', admin.site.urls),#django自带后台
    path('bookSearch',bookSearch),#api
    path('',RedirectView.as_view(url='bookSearch')),#默认路径
]
