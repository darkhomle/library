from Module.Common import *
import cv2
##########################可调整参数#######################
imgSize = (360,480)#目标图片尺寸
##########################################################

def extractBookRect(img,pixTh=127):
    '''
    获得图片中书本的矩形框和二值化图片
    :param img: 图片矩阵
    :param pixTh: 二值化像素阈值
    :return:
    '''
    #转为灰度图
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, binary = cv2.threshold(gray,pixTh, 255, cv2.THRESH_BINARY)
    contours, hierarchy = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    #找到最大轮廓
    maxIndex = 0
    # 挨个检查看那个轮廓面积最大
    maxArea = 0
    for i in range(len(contours)):
        if (cv2.contourArea(contours[i]) > maxArea) and (cv2.contourArea(contours[i])<(imgSize[0]*imgSize[1]*0.8)):
            maxIndex = i
            maxArea = cv2.contourArea(contours[i])
    #找出能包围该轮廓的最小矩形
    rect = cv2.minAreaRect(contours[maxIndex])
    return binary,rect

def extractBook(img):
    '''
    扣取书籍图片
    :param img: 图片矩阵
    :return: 二值化图，画出矩形框的图，书本图
    '''
    img = cv2.resize(img,imgSize)
    binary, rect = extractBookRect(img,127)
    angle = rect[-1]
    #画一个有偏角的矩形框
    box = cv2.boxPoints(rect)
    box = np.int0(box)
    markImg = img.copy()
    cv2.drawContours(markImg, [box], 0, (0, 0, 255), 2)
    #图片中心
    center = (imgSize[0] / 2, imgSize[1] / 2)
    #仿射变换
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    img = cv2.warpAffine(img, M, (imgSize[0], imgSize[1]), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

    #再次提取书本框
    _, rect = extractBookRect(img, 127)
    #裁剪目标框
    box = cv2.boxPoints(rect)
    box = np.int0(box)
    xmin = np.min(box[:,0])
    xmax = np.max(box[:,0])
    ymin = np.min(box[:,1])
    ymax = np.max(box[:,1])
    boxImg = img[ymin:ymax,xmin:xmax]
    boxImg = cv2.resize(boxImg,imgSize)
    return binary,markImg,boxImg

def calOneChannelHistSim(img1, img2):
    '''计算单通道的直方图的相似值'''
    hist1 = cv2.calcHist([img1], [0], None, [256], [0.0, 255.0])
    hist2 = cv2.calcHist([img2], [0], None, [256], [0.0, 255.0])
    # 计算直方图的重合度
    degree = 0
    for i in range(len(hist1)):
        if hist1[i] != hist2[i]:
            degree = degree + (1 - abs(hist1[i] - hist2[i]) / max(hist1[i], hist2[i]))
        else:
            degree = degree + 1
    degree = degree / len(hist1)
    return degree

def calHistSim(img1,img2):
    '''计算2张图片的直方图相似度，公式可参考 https://www.jianshu.com/p/9570a12436fa'''
    #按通道分离出3个图片
    sub_img1 = cv2.split(img1)
    sub_img2 = cv2.split(img2)
    #每个通道分别算相似度，最后求均值
    sub_data = 0
    for im1, im2 in zip(sub_img1, sub_img2):
        sub_data += calOneChannelHistSim(im1, im2)
    sim = sub_data / 3
    return sim

def compareTwoImageByPath(imgPath1,imgPath2):
    '''
    通过2个图片路径来计算图片相似度
    :param imgPath1: 路径1
    :param imgPath2: 路径2
    :return: 标记图和裁剪图，相似度
    '''
    img1 = cv2.imdecode(np.fromfile(imgPath1, dtype=np.uint8), -1)
    binary1, markImg1, boxImg1 = extractBook(img1)
    img2 = cv2.imdecode(np.fromfile(imgPath2, dtype=np.uint8), -1)
    binary2, markImg2, boxImg2 = extractBook(img2)
    try:
        sim = calHistSim(boxImg1,boxImg2)[0]
    except:
        sim = calHistSim(boxImg1,boxImg2)
    sim = float(sim)
    return sim,markImg1,boxImg1,markImg2,boxImg2

if __name__ == "__main__":
    imgPath1 = staticDir+"/test1.png"
    imgPath2 = staticDir+"/Book Image/Construction and interpretation of computer programs.png"
    sim, markImg1, boxImg1, markImg2, boxImg2 = compareTwoImageByPath(imgPath1,imgPath2)
    cv2.imshow("",markImg1)
    cv2.waitKey(0)