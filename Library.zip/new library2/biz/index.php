<?php 
require_once '../dao/userDao.php';
if(isset($_SESSION['CURRENT_USER_OK'])&&$_SESSION['CURRENT_USER_OK']<>"1"){
	header("Location:login.php");
	exit;
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
	<link rel="stylesheet" href="style/reset.css" />
	<link rel="stylesheet" href="style/login.css" />
</head>
<body>
<div class="page">
	<div class="loginwarrp">
		<div class="logo">Administrator Login</div>
        <div class="login_form">
            <form name="login" method="post" action="dologinpass.php" onSubmit="return checkform();">
				<li class="login-item">
					<span>Username:</span>
					<input type="text" name="admin" class="login_input">
				</li>
				<li class="login-item">
					<span>Password:</span>
					<input type="password" name="password" class="login_input">
				<div class="clearfix">
				<li class="login-sub">
                                    <input type="submit" name="Submit" value="Login" />
									<a href="../index.php" target="_blank">[Back to site home]</a></li> </div>             
           </form>
		</div>
	</div>
</div>
</body>
</html>