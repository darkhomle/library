<?php
require_once '../dao/globle.inc.php';
require_once '../dao/productsinfoDao.php';
require_once '../dao/producttypeDao.php';
$x_keys='';
$type='0';
if(isset($_POST['act'])&&$_POST['act']=='search'&&$_POST['keyword']!=''){
	$x_m=$_POST['act'];
	$type=$_POST['type'];
	$x_keys=$_POST['keyword'];
	$result = searchProductinfoByName(0,$x_keys,$type);
	
}else{
	$result = findAllproductinfo(0);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Information Management</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="Js/check.js"></script>
<script language="javascript">
function ask(msg) {
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body style="overflow-x:hidden;">
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageproduct.php">Book Management</a>| <a href="doaddproduct.php">Add Books</a>
    </ul>
  </div>
  <script>
	//|str_replace=.'/index.php','',###
	var onurl ='domanageproduct.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
	</script>
  <table  class="search_table" width="100%">
    <tr>
      <td class="search">
	  <form action="" method="post">
          <input id="keyword" type="text" size="14" class="input-text" name="keyword" value="<?php echo $x_keys;?>" />
		  <select name='type' style="height:30px;">
		  <option value='0' <?php if($type==0){echo 'selected';}?>>---Select type---</option>
		  <option value='1' <?php if($type==1){echo 'selected';}?>>Book name</option>
		  <option value='2' <?php if($type==2){echo 'selected';}?>>Author</option>
		  </select>
          <input type="submit" value="Search"  class="button" />
          <input type="reset" value="Reset" class="button"  />
          <input type="hidden" name="act" value="search" class="button"  />
        </form></td>
    </tr>
  </table>
  <form name="addform" id="addform" action="?del=checkbox" method="post">
   
    <div class="table-list">
      <table width="100%" cellspacing="0">
        <thead>
          <tr><th width="3%">ID</th>
            <th width="12%">Book name</th>
            <th width="5%">Picture</th>
            <th width="8%">Author</th>
            <th width="8%">Publisher</th>
            <th width="5%">Price</th>
            <th width="5%">Number</th>
            <th width="10%">Managing operations</th>
          </tr>
        </thead>
        <tbody>
        <?php
		if(empty($result)){?>
			 <tr>
				<td align="center" colspan="8">No suitable books found~</td>
			 </tr>
		<?php }else{
			foreach($result as $k=>$row){
				$ProductType = findProductTypeById($row['typeID']);
			
			  ?>
			  <tr>
				<td align="center"><?php echo $row['productID'];?></td>
				<td align="center"><?php echo '['.trim($ProductType['typeName']).']'.$row['productName'];?></td>
			   
				<td align="center"><img src="./upload/<?php echo $row['image'];?>"  width="30"></td>
				<td align="center"><?php echo $row['zuozhe'];?></td>
				<td align="center"><?php echo $row['chubanshe'];?></td>
				<td align="center"><?php echo $row['price'];?></td>
				<td align="center"><?php echo $row['num'];?></td>
				<td align="center">
				<a href="doeditproduct.php?id=<?php echo $row['productID'];?>">View / Edit</a> 
				| <a href="javascript:if(ask('Warning: Deletions will not be recoverable and may have unintended consequences?')) location.href='dodelproduct.php?id=<?php echo $row['productID'];?>';" onClick="delcfm();">Delete</a></td>
			  </tr>
			  <?php
			}
		}
		?>
        </tbody>
      </table>
    </div>
    
  </form>
</div>
</body>
</html>