<?php
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php';
require_once '../dao/productsinfoDao.php';
require_once '../dao/cartDao.php';


$color = array(
0=>"RGBA(0,176,80,1)"
,1=>"RGBA(192,0,0,1)"
,2=>"RGBA(255,192,0,1)"
,3=>"RGBA(0,176,240,1)"
,4=>"RGBA(112,48,160,1)"
,5=>"RGBA(192,90,17,1)"
,6=>"RGBA(255,0,0,1)"
,7=>"RGBA(255,255,0,1)"
,8=>"RGBA(51,255,0,1)"
,9=>"RGBA(220,112,101,1)"
,10=>"RGBA(191,144,0,1)"
,11=>"RGBA(208,149,177,1)"
,12=>"RGBA(111,164,143,1)"
,13=>"RGBA(0,51,255,1)"
,14=>"RGBA(204,0,255,1)"
,15=>"RGBA(255,0,153,1)"
);
    
    $result =  findAllproductinfo(0);
	
	
	$str = '';
	$i = 1;
	if(isset($_POST)&&!empty($_POST)){
		$v = findProductinfoById($_POST['productID']);
		
	}else{
		$v = $result[0];
		
	}	
		$productID = $v['productID'];
	    $value = conutBrow($v['productID']);
		$value2 = conutBrowOther($v['productID']);
		
		$str[0]['name'] = $v['productName'];
		$str[0]['value'] = (int)$value['c'];
		$str[0]['color'] = $color[$i];
		$i++;
		$str[1]['name'] = 'Other books';
		$str[1]['value'] = (int)$value2['c'];
		$str[1]['color'] = $color[$i];
    $tmp="";
	$i=0;
    foreach($str as $k=>$row){
				
		$tmp[$i]['name'] = $row['name'];
		$tmp[$i]['value'] = (int)$row['value'];
		$tmp[$i]['color'] = $row['color'];
		$i++;
	} 
	
	$shouru = json_encode($tmp);

function conutBrow($productID){
	
	$sql="select count(*) as c from tblcart where productID='$productID' ";
	return execQueryOne($sql);
}
function conutBrowOther($productID){
	
	$sql="select count(*) as c from tblcart where productID!='$productID' ";
	return execQueryOne($sql);
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<title>Administrator Management</title>
<script language="javascript">
function ask(msg) {
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body>
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageorder.php">Loan Management</a>
    </ul>
    <div class="clear"></div>
  </div>
    
 
<div class="table-list">
   <form action="" method="post">Select a book:
   <select name="productID"><?php foreach($result as $k=>$v){
	   ?>
	   <option value="<?php echo $v['productID'];?>" <?php if($v['productID']==$productID){echo 'selected';}?> ><?php echo $v['productName'];?></option>
	   <?php 
	   
   }?>
	<input type="submit" name="s" value="Submit"/>
	</select>
	</form>
<div class="page-content width" style="margin-bottom:50px;">
<script src="Js/pie.js"></script>  
<script src="Js/fenxi.js"></script>  

<script>  
    window.onload = function() {  
        var canvas = document.getElementById("pie_canvas");  
        var seriesData = <?php echo $shouru;?>; 
        var config = {  
                width : 899,   
                height: 400,  
                series: seriesData,  
                canvas: canvas,  
                unit: "Pieces",  
                title:"Book Borrowing Ratio Chart",  
                tooltips : {  
                    enable : true  
                },  
                animation :{  
                    enable: true  
                },  
                legend : {  
                    enable : true  
                },  
                text : {  
                    enable: true  
                },  
        };  
        pieChart.initSettings(config);  
        pieChart.render();  
    }  
    </script>  

<div id="my_container" style="width:899px; height:500px;">  
    <canvas id="pie_canvas"></canvas>  
</div>  
</div>
	  
    </div>
</div>
</body>
</html>
