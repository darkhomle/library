<?php 
require_once '../dao/globle.inc.php';
require_once '../dao/producttypeDao.php';
$typeID =$_GET["id"];
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	
	$typeID = $_POST['id'];
	$typeName = $_POST['typeName'];
	updateProductType($typeName,$typeID);

	echo "<script language='javascript'>"; 
	echo "alert('Modified successfully!');";
	echo " location='domanageproductclass.php';"; 
	echo "</script>";
	
}
$e_rs=findProductTypeById($typeID);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book information</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="js/laydate.js"></script>
</head>
<body style="overflow-x:hidden;">
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageproduct.php">Library Information Management</a>| <a href="doaddproduct.php">Add books</a>|
    </ul>
    <div class="clear"></div>
  </div>
  <script>
	var onurl ='domanageproduct.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
	</script>
  <div id="msg"></div>
  <form name="addform" id="addform" action="" method="post" enctype="multipart/form-data">
    <table cellpadding=0 cellspacing=0 class="table_form" width="100%">
      <tr>
        <td width="10%" ><font color="red">*</font>Name</td>
        <td width="90%" >
          <input type="text" class="input-text" name="typeName"  id="name"  size="55" value="<?php echo $e_rs['typeName'];?>" />
          &nbsp;
          <input type="hidden" name="id" value="<?php echo $typeID;?>" /></td>
      </tr>

    </table>
    <div id="bootline"></div>
    <div id="btnbox" class="btn">
      <INPUT TYPE="submit" value="Submit" class="button" onClick='javascript:return checkaddform()'>
      <input TYPE="reset"  value="Cancel" class="button">
      <input TYPE="hidden" value="ok" name="act" class="button">
    </div>
  </form>
</div>
</body>
</html>
<script>
laydate({
    elem: '#c_date', 
    event: 'focus'
	});
</script>
<?php
function get_str($typeID) { 
   $result = findtypeNameAll();
  $str='';
    if($result){//如果有子类 
       foreach($result as $k=>$row){ //循环记录集 
		    if($row['typeID']==$typeID){
				$select="selected='selected'";
			}else{
				$select="";
			}
            $str .= "<option value='".$row['typeID']."' $select>".$row['typeName']."</option>"; //构建字符串 
        } 
    } 
    return $str; 
}
?>