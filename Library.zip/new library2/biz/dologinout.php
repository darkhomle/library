<?php  

header('Content-Type:text/html;charset=utf-8');

unset($_SESSION);
echo "<script language='javascript'>"; 
echo "alert('Exit successful');";
echo " location='index.php';"; 
echo "</script>";
?>