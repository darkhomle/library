<?php
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php';
require_once '../dao/productsinfoDao.php';
require_once '../dao/cartDao.php';

$x_keys='';
$type='0';
if(isset($_POST['act'])&&$_POST['act']=='search'&&$_POST['keyword']!=''){
	$x_m=$_POST['act'];
	$type=$_POST['type'];
	$x_keys=$_POST['keyword'];
	$result = searchProductinfoByName(0,$x_keys,$type);
	
	$p_arr = array();
	foreach($result as $k=>$v){
		$p_arr[]=$v['productID'];
	}
	$p_str = implode("','",$p_arr);
	$sql="select *from tblcart where productID in('{$p_str}');";
	
    $resultporduct = execQueryAll($sql);
	 
}else{
	 $resultporduct = findCarts();
}

if(isset($_GET['cartID'])&&!empty($_GET['cartID'])){
	$result = ReturnCart($_GET['cartID']);
	$result = setPorductNum($_GET['productID'],1);
	if($result){
		echo "<script> alert('Returned successfully');windows.location.href='./domanageorder.php'; </script>";
	}
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<title>Administrator Management</title>
<script language="javascript">
function ask(msg) {
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body>
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageorder.php">Loan Management</a>
    </ul>
    <div class="clear"></div>
  </div>
    <table  class="search_table" width="100%">
    <tr>
      <td class="search">
	  <form action="" method="post">
          <input id="keyword" type="text" size="14" class="input-text" name="keyword" value="<?php echo $x_keys;?>" />
		  <select name='type' style="height:30px;">
		  <option value='0' <?php if($type==0){echo 'selected';}?>>---Select type---</option>
		  <option value='1' <?php if($type==1){echo 'selected';}?>>Book name</option>
		  <option value='2' <?php if($type==2){echo 'selected';}?>>Author</option>
		  </select>
          <input type="submit" value="Search"  class="button" />
          <input type="hidden" name="act" value="search" class="button"  />
        </form></td>
    </tr>
  </table>
  <form name="addform" action="" method="post">
    <div class="table-list">
      <table width="100%" cellspacing="0">
        <thead>
          <tr>
            <th width="40">id</th>
            <th width="30">Picture</th>
			 <th width="230">Book</th>
			 <th width="45">Number</th>
			 <th width="105">Appointment holders</th>
			 <th width="105">Status</th>
			 <th width="125">Time</th>
			 <th  width="105">Operation</th>
          </tr>
        </thead>
        <tbody>
<?php
   
    if(!empty($resultporduct)){
	foreach($resultporduct as $k=>$v){
		$Productinfo = findProductinfoById($v['productID']);
		$Userinfo = findUserinfoById($v['userID']);
	    $flag = ($v['flag']==1)?'On loan':'Returned';
	    $flag = ($v['flag']==3)?'Renewal':$flag;
		?>
		<tr>
		 <td><?php echo $v['cartID'];?></td>
		 <td><img src="./upload/<?php echo $Productinfo['image'];?>" width="85" height="85" style="border:1px solid #ccc;padding:1px;" /></td>
		 <td><?php echo $Productinfo['productName'];?> </td>
		 <td><?php echo $Productinfo['num'];?></td>
		 <td><?php echo $Userinfo['uName'];?></td>
		 <td><?php echo $flag;?></td>
		 <td><?php 
		 echo 'Loan：'.date('Y/m/d',strtotime($v['c_date']));
		 echo '<br>';
		 if($v['u_date']!='0000-00-00 00:00:00'){
			  echo 'Return：'.date('Y/m/d',strtotime($v['u_date']));
		 }
		
		 ?></td>
		 <td>
		 <?php 
		 if($v['flag']==1){?>
			 <a href="domanageorder.php?cartID=<?php echo $v['cartID'];?>&productID=<?php echo $v['productID'];?>" class="green"> Return</a>
		 <?php  }?>
		
		</td>
		</tr>
	<?php } 
	}else{?>
		<tr><td colspan="6">No suitable data is available at the moment!</td></tr>
	<?php }?>
     </tbody>
      </table>
    </div>
  </form>
</div>
</body>
</html>
