<?php
require_once '../dao/globle.inc.php';
require_once '../dao/newsDao.php';
$id=$_GET["id"];
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	//图片更改时
	if(isset($_FILES["file"]["name"])&&!empty($_FILES["file"]["name"])){
		// 允许上传的文件后缀
		$allowedExts = array("jpg","jpeg", "gif", "png", "bmp");
		$temp = explode(".", $_FILES["file"]["name"]);

		$extension = end($temp);     // 获取文件后缀名
		if (($_FILES["file"]["size"] < 2048000)   // 小于 2mb
		&& in_array($extension, $allowedExts))
		{
			if ($_FILES["file"]["error"] > 0)
			{
				echo "<script>alert('Error： " . $_FILES["file"]["error"] . "\\n');</script>";
			}
			else
			{
				$tmp_name =  date('YmdHis').mt_rand(10,100).'_'.$_FILES["file"]["name"];
				$fpath="upload/" .$tmp_name;
				if (file_exists("upload/" . $tmp_name))
				{
					echo "<script>alert('".$tmp_name . " File already exists ');</script>";
				}
				else
				{
					$id  = $_POST['id'];
					$name  = $_POST['name'];
					$detail =$_POST['detail'];
					$image = $tmp_name;
					updateNews($id,$name,$detail,$image);
					move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $tmp_name);
					//$db->close();
					echo "<script language='javascript'>"; 
					echo "alert('Modified successfully!');";
					echo " location='news_list.php';"; 
					echo "</script>";
				}
			}
		}
		else
		{
			echo "<script>alert('Document format error');location='news_edit.php'</script>";
		}
	}else{
		$name  = $_POST['name'];
		$detail =$_POST['detail'];
		$image = $tmp_name;
		updateNews($id,$name,$detail,$image);
	
		echo "<script language='javascript'>"; 
		echo "alert('Modified successfully!');";
		echo " location='news_list.php';"; 
		echo "</script>";
	}
}
$e_rs=findNewsById($id);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Help information</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="js/laydate.js"></script>
</head>
<body style="overflow-x:hidden;">
<div id="loader" >Loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="news_list.php">Help management</a>| <a href="news_add.php">Add help</a>|
    </ul>
    <div class="clear"></div>
  </div>
  <script>
	var onurl ='news_list.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
	</script>
  <div id="msg"></div>
  <form name="addform" id="addform" action="" method="post" enctype="multipart/form-data">
    <table cellpadding=0 cellspacing=0 class="table_form" width="100%">
      <tr>
        <td width="10%" ><font color="red">*</font>Title</td>
        <td width="90%" >
          <input type="text" class="input-text" name="name"  id="name"  size="55" value="<?php echo $e_rs['name'];?>" />
          &nbsp;
          <input type="hidden" name="id" value="<?php echo $id;?>" /></td>
      </tr>
     <tr>
        <td width="10%" ><font color="red">*</font>Picture</td>
        <td width="90%" ><?php echo $e_rs['image'];?><br>
          <label for="file">File selection:</label>
	
	  <input type="hidden" name="image" id="image" value="<?php echo $e_rs['image'];?>">
	  <input type="file" name="file" id="file">
          <br>Image names must be all English or numeric otherwise they will not be represented properly</td>
      </tr>
      <tr>
        <td width="10%" >Description<font color="red">*</font></td>
        <td width="90%" id="box_pics"><textarea name="detail" id="b_detail" cols="85" rows="8"><?php echo $e_rs['detail'];?></textarea></td>
      </tr>
    </table>
    <div id="bootline"></div>
    <div id="btnbox" class="btn">
      <INPUT TYPE="submit" value="submit" class="button" onClick='javascript:return checkaddform()'>
      <input TYPE="reset"  value="cancel" class="button">
      <input TYPE="hidden" value="ok" name="act" class="button">
    </div>
  </form>
</div>
</body>
</html>
<script>
laydate({
    elem: '#c_date', 
    event: 'focus'
	});
</script>