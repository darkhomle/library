<?php  
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php';
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	$uId=$_POST['id'];
	$uName=strtolower(trim($_POST['uName']));
	$uPass=trim($_POST['uPass']);
	$uKind=trim($_POST['uKind']);
	$address=trim($_POST['address']);
	$card_no=trim($_POST['card_no']);
	$tel=trim($_POST['tel']);
	$re_uPass=trim($_POST['re_uPass']);
	
	if(empty($uName)){
	  echo("<script type='text/javascript'> alert('Username cannot be empty'); window.history.back();</script>");
		 exit;
	}elseif(empty($uPass)){
	  echo("<script type='text/javascript'> alert('Password cannot be empty'); window.history.back();</script>");
		 exit;
	}elseif(empty($card_no)){
	  echo("<script type='text/javascript'> alert('ID number cannot be empty'); window.history.back();</script>");
		 exit;
	}else{
		 updateUserinfo($uName, $uPass,$uKind, $address,$card_no,$tel,$uId);
		
		echo "<script language='javascript'>"; 
		echo "alert('Modified successfully!');";
		echo " location='domanageuser.php';"; 
		echo "</script>";
	}
}
$sxid=$_GET["id"];
$e_rs=findUserinfoById($sxid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Information added</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
</head>
<body >
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageuser.php">User Management</a>| <a href="doadduser.php">Add user</a>
    </ul>
    <div class="clear"></div>
  </div>
  <script>
	//|str_replace=.'/index.php','',###
	var onurl ='manage_info.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
  </script>
  <div id="msg"></div>
  <form name="addform" id="addform" action="?act=ok" method="post">
    <table cellpadding=0 cellspacing=0 class="table_form" width="100%">
      <tr>
        <td width="10%" >Username</td>
        <td width="90%" >
          <input type="text" class="input-text" name="uName"  id="title"  size="55" value="<?php echo $e_rs['uName'];?>" />
		  <input name="id" type="hidden" value="<?php echo $sxid;?>" /> 
		  <font color="red">*</font>
          </td>
      </tr>
      <tr>
        <td width="10%" >Type</td>
        <td width="90%" >
         <input type="radio" name="uKind" value="0" <?php if($e_rs['uKind']==0){echo 'checked';}?>>Anonymous user
         <input type="radio" name="uKind" value="1" <?php if($e_rs['uKind']==1){echo 'checked';}?>>Administrator
         <input type="radio" name="uKind" value="2" <?php if($e_rs['uKind']==2){echo 'checked';}?>>Blacklist
          </td>
      </tr>
      <tr>
        <td width="10%" >Password</td>
        <td width="90%"><input type="text" name="uPass"  value="<?php echo $e_rs['uPass'];?>" class="input-text" size="55" /> <font color="#FF0000"><strong>[Cannot be empty]</strong></font></td>
      </tr>
      <tr>
        <td width="10%" >ID number</td>
        <td width="90%"><input type="text" name="card_no" value="<?php echo $e_rs['card_no'];?>"class="input-text" size="55" /></td>
      </tr>
      <tr>
        <td width="10%" >Phone</td>
        <td width="90%"><input type="text" name="tel" value="<?php echo $e_rs['tel'];?>"class="input-text" size="55" /></td>
      </tr>
      <tr>
        <td width="10%" >Address</td>
        <td width="90%"><input type="text" name="address" value="<?php echo $e_rs['address'];?>"class="input-text" size="55" /></td>
      </tr>
    </table>
    <div id="bootline"></div>
    <div id="btnbox" class="btn">
      <INPUT TYPE="submit"  value="Submit" class="button" >
      <input TYPE="reset"  value="Cancel" class="button">
      <input TYPE="hidden"  name="act" value="ok" class="button">
    </div>
  </form>
</div>
</body>
</html>