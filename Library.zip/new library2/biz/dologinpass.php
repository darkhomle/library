<?php 
require_once '../dao/globle.inc.php';
require_once '../dao/userDao.php';
//登录验证
if(isset($_POST["admin"]) && isset($_POST["password"])){
    $uName = trim($_POST["admin"]);
    $uPass = $_POST["password"];
 
	$Userinfo = findUserinfoByNamePwd($uName,$uPass);
    if(!empty($Userinfo)&&$Userinfo['uKind']==1){
	
		$_SESSION['login'] = 1;
		$_SESSION['loginuser'] = $Userinfo ;
		$_SESSION["m_name"] = $Userinfo['uName'];
		echo "<script language='javascript'>"; 
		echo "alert('Login success');";
		echo " location='domain.php';"; 
		echo "</script>";
	
	}else{
		echo "<script language='javascript'>"; 
		echo "alert('Incorrect account or password!');";
		echo " location='index.php';"; 
		echo "</script>";
		exit();
	}
}
?>
