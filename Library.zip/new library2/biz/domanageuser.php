<?php require_once '../dao/userDao.php';?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<title>Administrator Management</title>
<script language="javascript">
function ask(msg) { 
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body>
<div id="loader" >Pages are loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="domanageuser.php">User Management</a>| <a href="doadduser.php">Add user</a>
    </ul>
    <div class="clear"></div>
  </div>
  <script>
	//|str_replace=.'/index.php','',###
	var onurl ='domanageuser.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
  </script>
  <form name="addform" action="" method="post">
    <div class="table-list">
      <table width="100%" cellspacing="0">
        <thead>
          <tr>
            <th width="40">User id</th>
            <th>Username</th>
            <th width="140">Password</th>
            <th width="140">Id number</th>
            <th width="140">Address</th>
            <th width="140">Phone</th>
            <th width="140">Type</th>
            <th width="220">Management Operations</th>
          </tr>
        </thead>
        <tbody>
         
<?php
    $result = findUserinfos();
  
    $str="";
    foreach($result as $k=>$row){
		$kind='Ordinary users';
		if($row['uKind']==1){
			$kind='Administrators';
		}
		if($row['uKind']==2){
			$kind='Black list';
		}
		$str .="<tr>";
		$str .="<td align='center'>".$row['uID']."</td>";
		$str .="<td align='center'>".$row['uName']."</td>";
		$str .="<td align='center'>".$row['uPass']."</td>";
		$str .="<td align='center'>".$row['card_no']."</td>";
		$str .="<td align='center'>".$row['address']."</td>";
		$str .="<td align='center'>".$row['tel']."</td>";
		$str .="<td align='center'>".$kind."</td>";
	    $str .="<td align='center'> <a href='doedituser.php?id=".$row['uID']."'>View / Edit</a>
		 | <a href=\"javascript:if(ask('Warning: Deletions will not be recoverable and may have unintended consequences?'))"
		." location.href='dodeluser.php?id=".$row['uID']."';\">Delete</a></td>";
		$str .="</tr>";  
	} 
	echo $str;
 
?>
        </tbody>
      </table>
    </div>
  </form>
</div>
</body>
</html>