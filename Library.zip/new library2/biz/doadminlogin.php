<?php
require_once '../dao/userDao.php';
//if (isset($_REQUEST["userId"], $_REQUEST["userpwd"])) {
//从表单中读取登录信息
$userID = $_REQUEST["UserName"];
$userpwd = $_REQUEST["password"];

$curUser =  findUserByID($userID);
if (count($curUser) > 0){
        $userpwd == $curUser['userPwd'];
        $_SESSION["CURRENT_USER"] = $curUser;
        header("location:../index.php");
    }else{
echo "<script> alert('Please check that your account password matches');parent.location.href='../login.php'; </script>";
}
    ?>


