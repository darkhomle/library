<?php
require_once '../dao/globle.inc.php';
require_once '../dao/newsDao.php';
$x_keys='';
if(isset($_POST['act'])&&$_POST['act']=='search'&&$_POST['keyword']!=''){
	$x_m=$_POST['act'];
	$x_keys=$_POST['keyword'];
	$result = findAllnewsinfo($x_keys);
	
}else{
	$result = findAllnewsinfo();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Information Management</title>
<script type="text/javascript" src="Js/jquery.min.js"></script>
<link href="style/style.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="Js/check.js"></script>
<script language="javascript">
function ask(msg) {
	if( msg=='' ) {
		msg='Warning: Deletions will not be recoverable and may have unintended consequences?';
	}
	if (confirm(msg)) {
		return true;
	} else {
		return false;
	}
}
</script>
</head>
<body style="overflow-x:hidden;">
<div id="loader" >Loading...</div>
<div id="result" class="result none"></div>
<div class="mainbox">
  <div id="nav" class="mainnav_title">
    <ul>
      <a href="news_list.php">Help management</a>| <a href="news_add.php">Add help</a>
    </ul>
  </div>
  <script>
	//|str_replace=.'/index.php','',###
	var onurl ='news_list.php';
	jQuery(document).ready(function(){
		$('#nav ul a ').each(function(i){
		if($('#nav ul a').length>1){
			var thisurl= $(this).attr('href');
			if(onurl.indexOf(thisurl) == 0 ) $(this).addClass('on').siblings().removeClass('on');
		}else{
			$('#nav ul').hide();
		}
		});
		if($('#nav ul a ').hasClass('on')==false){
		$('#nav ul a ').eq(0).addClass('on');
		}
	});
	</script>
  <table  class="search_table" width="100%">
    <tr>
      <td class="search"><form action="" method="post">
          <input id="keyword" type="text" size="14" class="input-text" name="keyword" value="<?php echo $x_keys;?>" />
          <input type="submit" value="Search"  class="button" />
          <input type="reset" value="Reset" class="button"  />
          <input type="hidden" name="act" value="search" class="button"  />
        </form></td>
    </tr>
  </table>
  <form name="addform" id="addform" action="?del=checkbox" method="post">
   
    <div class="table-list">
      <table width="100%" cellspacing="0">
        <thead>
          <tr>
           
            <th width="5%">ID</th>
            <th width="20%">Title</th>
            <th width="10%">Picture</th>
            <th width="30%">Information</th>
            <th width="20%">Time</th>
            <th width="35%">Managing operations</th>
          </tr>
        </thead>
        <tbody>
        <?php
        foreach($result as $k=>$row){
		  ?>
          <tr>
            
            <td align="center"><?php echo $row['id'];?></td>
            <td align="center"><?php echo $row['name'];?>&nbsp;&nbsp;</td>
            <td align="center"><img src="./upload/<?php echo $row['image'];?>"  width="30"></td>
            <td align="center"><?php echo mb_substr($row['detail'],0,20,'utf-8').'...'; ?>&nbsp;&nbsp;</td>
            <td align="center"><?php echo $row['up_date'];?></td>
            <td align="center" style="white-space:nowrap;"><a href="news_edit.php?id=<?php echo $row['id'];?>">View/Edit</a> 
			| <a href="javascript:if(ask('Warning: Deletions will not be recoverable and may have unintended consequences？')) location.href='news_del.php?id=<?php echo $row['id'];?>';" onClick="delcfm();">Delete</a></td>
          </tr>
          <?php
		}
		?>
        </tbody>
      </table>
    </div>
    
  </form>
</div>
</body>
</html>