<?php 
require_once './dao/globle.inc.php';
require_once './dao/productsinfoDao.php';
require_once './dao/producttypeDao.php';
require_once './dao/cartDao.php';
require_once './dao/orderinfoDao.php';
if(isset($_GET['cartID'])&&!empty($_GET['cartID'])&&$_GET['flag']=='return'){
	$result = ReturnCart($_GET['cartID']);
	$result = setPorductNum($_GET['productID'],1);
	if($result){
		echo "<script> alert('Book return success');parent.location.href='./car.php'; </script>";
	}
}
if(isset($_GET['cartID'])&&!empty($_GET['cartID'])&&$_GET['flag']=='add'){
	
	$result = alertCart($_GET['cartID']);
	$result = RenewalCart($_GET['cartID']);

	if($result){
		echo "<script> alert('Successful renewal');parent.location.href='./car.php'; </script>";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
 <div class="mianCont">
  <div class="top">
  <?php echo login_top();?>
  <div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="#" method="get" class="subBox">
    <div class="subBoxDiv">
     <input type="text" class="subLeft" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" /><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
     <ul class="InPorNav">
    
    </ul><!--InPorNav/-->
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
      <li><a href="biz/index.php">Add books</a></li>
	  <li><a href="help.php">Help</a></li>
     <div class="clears"></div>
     <div class="phone"><a href="test.php">Book Recognition</a></div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
  Current position: <a href="#" class="posCur">Loan List</a>
  </div><!--positions/-->
  <div class="cont">
 
    <form id="myForm" name="cart" method="post" action="">
	 <input type="hidden" value="" name="type" id="type"/>
    <table class="orderList">
    <tr>
     <th width="20"></th>
     <th width="30">Picture</th>
     <th width="230">Books</th>
     <th width="105">Price</th>
     <th width="105">Author</th>
     <th width="105">Publisher</th>
     <th width="105">Status</th>
     <th width="125">Time</th>
     <th  width="45">Operation</th>
    </tr>
	<?php 
	$userID = $_SESSION["CURRENT_USER"]['uID'];
	$resultporduct = findCartByUId($userID);
	$total_price = 0;
	if(!empty($resultporduct)){
	foreach($resultporduct as $k=>$v){
		$Productinfo = findProductinfoById($v['productID']);
	    $flag = ($v['flag']==1)?'On loan':'Already returned';
	    $flag = ($v['flag']==3)?'Renewal':$flag;
		?>
		<tr>
		 <td></td>
		 <td><img src="./biz/upload/<?php echo $Productinfo['image'];?>" width="85" height="85" style="border:1px solid #ccc;padding:1px;" /></td>
		 <td><?php echo $Productinfo['productName'];?> </td>
		 <td><?php echo $Productinfo['price'];?></td>
		 <td><?php echo $Productinfo['zuozhe'];?></td>
		 <td><?php echo $Productinfo['chubanshe'];?></td>
		 <td><?php echo $flag;?></td>
		 <td style="text-align:left;"><?php 
		
		 echo 'Loan：&nbsp;&nbsp;&nbsp;'.date('Y/m/d',strtotime($v['c_date']));
		 echo '<br>';
		 echo 'Return：';
		 if($v['u_date']!='0000-00-00 00:00:00'&&$v['u_date']!=NULL&&!empty($v['u_date'])){
			  echo date('Y/m/d',strtotime($v['u_date']));
		 }
		  //借阅超时
			
			 
			 $diff_d = (time()-strtotime($v['c_date']))/86400;
			 $diff_d = round($diff_d);
			 $diff2= $diff_d-20;
			 
		  if($v['u_date']=='0000-00-00 00:00:00'||empty($v['u_date'])){
			
			 echo 'Already <font color=red>'.$diff_d.'</font> days yet to return'; 
			 if($diff2>=1){
				echo '(Overdue <font color=red><b>'.$diff2.'</b></font> days)';
			 }
			
		   if($diff2>=1){
				echo 'Overdue charges：'.($diff2*10).'Yuan';
		   }
		  }
		 ?></td>
		 <td>
		 <?php 
		 if($v['flag']==1||$v['flag']==3){?>
			 <a href="car.php?cartID=<?php echo $v['cartID'];?>&productID=<?php echo $v['productID'];?>&flag=return" class="green"> Return</a>
			 <br>
			 <?php if($diff_d>=7){
				  if($v['flag']==1){
				 ?>
				  <a href="car.php?cartID=<?php echo $v['cartID'];?>&flag=add" class="blue"> Renewal</a>
				 <?php 
				  }
			 }
			
		  }?>
		
		
		</td>
		</tr>
	<?php } 
	}else{?>
		<tr><td colspan="6">No suitable data available at the moment! </td></tr>
	<?php }?>
   </table><!--orderList/-->
  
   </form>
   <!--jiesuan/-->
   <div class="clears"></div>`
  </div><!--cont/--><!--inHelp/-->
<?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
 <script>
 function carsubmit(type){
	document.getElementById("type").value=type;
	document.getElementById("myForm").submit()
 }
 </script>
</body>
</html>
