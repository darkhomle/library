-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2022-04-28 22:00:11
-- 服务器版本： 5.7.26
-- PHP 版本： 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `new_library`
--
CREATE DATABASE IF NOT EXISTS `new_library` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `new_library`;

-- --------------------------------------------------------

--
-- 表的结构 `tblcart`
--

DROP TABLE IF EXISTS `tblcart`;
CREATE TABLE `tblcart` (
  `cartID` int(11) NOT NULL COMMENT '借阅ID',
  `userID` int(11) DEFAULT NULL COMMENT '用户编号',
  `productID` int(11) DEFAULT NULL COMMENT '商品编号',
  `flag` int(11) DEFAULT '1' COMMENT '归还1=借阅2=续借3',
  `c_date` datetime DEFAULT NULL COMMENT '借阅时间',
  `u_date` datetime DEFAULT NULL COMMENT '归还时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tblcart`
--

INSERT INTO `tblcart` (`cartID`, `userID`, `productID`, `flag`, `c_date`, `u_date`) VALUES
(1, 5, 2, 2, '2020-09-04 07:49:51', '2020-08-29 07:52:55'),
(2, 5, 3, 2, '2020-08-27 07:56:15', '2020-08-29 08:33:13'),
(3, 5, 11, 1, '2020-08-27 09:32:08', '0000-00-00 00:00:00'),
(7, 5, 2, 2, '2020-08-28 09:39:59', '2020-08-30 09:40:22'),
(8, 5, 3, 2, '2020-08-28 09:41:06', '2020-10-30 10:52:28'),
(11, 5, 3, 2, '2020-08-28 09:42:53', '2020-08-30 09:43:22'),
(12, 5, 3, 2, '2020-08-28 09:44:46', '2020-08-30 09:44:57'),
(13, 5, 3, 2, '2020-08-28 09:45:05', '2020-08-30 09:45:15'),
(14, 5, 3, 1, '2020-08-28 09:49:50', '0000-00-00 00:00:00'),
(15, 11, 11, 1, '2020-08-27 06:17:00', '0000-00-00 00:00:00'),
(16, 10, 11, 2, '2020-08-28 07:39:24', '2020-08-28 09:17:02'),
(17, 5, 11, 1, '2020-08-28 08:45:25', '0000-00-00 00:00:00'),
(18, 5, 11, 1, '2020-08-28 08:50:08', '0000-00-00 00:00:00'),
(19, 5, 1, 1, '2020-08-28 14:49:52', '0000-00-00 00:00:00'),
(20, 7, 1, 1, '2020-10-12 08:02:52', '0000-00-00 00:00:00'),
(21, 7, 2, 1, '2020-10-08 04:59:14', '0000-00-00 00:00:00'),
(22, 10, 2, 2, '2020-10-07 12:45:38', '0000-00-00 00:00:00'),
(23, 2, 2, 1, '2020-12-02 04:03:10', '0000-00-00 00:00:00'),
(24, 4, 2, 1, '2021-01-16 12:27:22', '0000-00-00 00:00:00'),
(25, 12, 2, 2, '2021-04-07 08:57:16', '2021-04-09 03:39:36'),
(26, 12, 2, 1, '2021-04-15 16:11:55', '0000-00-00 00:00:00'),
(27, 12, 3, 1, '2021-04-08 16:26:03', '0000-00-00 00:00:00'),
(28, 13, 2, 3, '2022-04-15 21:43:42', NULL),
(29, 13, 3, 3, '2022-04-15 21:52:04', NULL),
(30, 13, 3, 2, '2022-04-08 21:53:21', '2022-04-28 21:55:06'),
(31, 13, 4, 2, '2022-04-28 21:54:54', '2022-04-28 21:55:01');

-- --------------------------------------------------------

--
-- 表的结构 `tblnews`
--

DROP TABLE IF EXISTS `tblnews`;
CREATE TABLE `tblnews` (
  `id` int(11) NOT NULL COMMENT 'id',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '资讯名称',
  `detail` text CHARACTER SET utf8 NOT NULL,
  `image` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '图片',
  `up_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tblnews`
--

INSERT INTO `tblnews` (`id`, `name`, `detail`, `image`, `up_date`) VALUES
(1, '如何在系统借阅', '1.选择你要借阅的图书,单击图书图片进入详情页面\r\n<br><br>\r\n2。选择借阅的图书,点击”立即借阅“ 接着在弹出框中,点击”下一步“进入确认页面\r\n<br><br>', '2021040905091974_2021-04-09_110904.jpg', '2021-04-09 05:09:19'),
(2, '如何成为新会员', '首先从电脑PC端登录页面，任务商城注册会员需要姓名、电话、身份证信息，保证会员的信息真实性，同时商城也会保护会员的隐私，提高会员在本商城消费服务的体验。\r\n<Br>\r\n<Br>\r\n其次，手机端的也可以进行会员注册，注册流程也跟PC电脑端的一样，一般只需要2分钟左右即可完成会员注册，完成会员注册的会员直接可以享受到商城的优惠。\r\n<Br>\r\n<Br>\r\n最后，无论是电脑、手机会员注册完成后，都会收到任务商城的信息服务提醒，提示您已经成功注册成为用户商城的会员。这个任务商城的信息服务是不额外收费，在会员套餐里边也有信息服务，但会员套餐的服务是收费的。', '2021040905064258_2021-04-09_110417.jpg', '2021-04-09 05:06:42');

-- --------------------------------------------------------

--
-- 表的结构 `tblnotice`
--

DROP TABLE IF EXISTS `tblnotice`;
CREATE TABLE `tblnotice` (
  `id` int(11) NOT NULL COMMENT 'id',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '资讯名称',
  `detail` text CHARACTER SET utf8 NOT NULL,
  `image` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '图片',
  `up_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tblnotice`
--

INSERT INTO `tblnotice` (`id`, `name`, `detail`, `image`, `up_date`) VALUES
(2, '本系统为国外客户开通', '本系统为国外客户开通', '2021040905064258_2021-04-09_110417.jpg', '2021-04-26 14:54:26'),
(3, '公告开通啦', '公告开通啦', '2021042616563251_2021-03-12_190611.jpg', '2021-04-26 16:56:32'),
(4, '菲菲', '123', '2021042616564074_2021-03-12_190446.jpg', '2021-04-26 16:56:40');

-- --------------------------------------------------------

--
-- 表的结构 `tblproducts`
--

DROP TABLE IF EXISTS `tblproducts`;
CREATE TABLE `tblproducts` (
  `productID` int(11) NOT NULL COMMENT '商品编号',
  `upUserID` int(11) NOT NULL,
  `typeID` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '类型编号',
  `productName` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '商品名称',
  `price` double(15,2) NOT NULL COMMENT '商品价格',
  `num` int(11) NOT NULL COMMENT '商品库存',
  `detail` text CHARACTER SET utf8 NOT NULL,
  `chubanshe` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '出版社',
  `zuozhe` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '商品图片'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tblproducts`
--

INSERT INTO `tblproducts` (`productID`, `upUserID`, `typeID`, `productName`, `price`, `num`, `detail`, `chubanshe`, `zuozhe`, `image`) VALUES
(1, 1, '6', '红楼梦', 59.00, 0, '本书为中国古典文学读本丛书。 如果你还在为了阅读或收藏价格昂贵的中国古典名著而在书架前徘徊，那么现在你不用愁了，该版的《红楼梦》，不仅价格便宜、印刷美观、装帧古朴，收藏、送人都让你特有面子！实为古典小说的', '人民文学出版社', '曹雪芹', '2018062616543660_2018-06-26_225350.jpg'),
(2, 1, '4', '扶摇皇后（套装全6册）', 140.40, 0, '扶摇皇后（套装全6册）(无删减完整版。杨幂×阮经天主演电视剧《扶摇》原著小说，随套附赠手工精裱“掌心莲”人物图卷）\r\n（参与@当当读书汇新浪微博“买扶摇赢金条”活动，即日起至7月30日，在当当自营或当当天猫旗舰店购买《扶摇皇后套装》加话题#买扶摇赢金条#晒订单，即有机会获得，请见详情页。白马时光） 青春正能量 青春动漫每99减50', '百花洲文艺出版社', '天下归元 白马时光', '2018062616413037_2018-06-26_224047.jpg'),
(3, 1, '7', '后来时间都与你有关', 36.00, 6, '畅销2年销量500万之后，仍然马不停蹄地一往无前。 遇见你，后来时间都与你有关 张皓宸，始终温暖陪伴！ 90后、颜值高、漫画家、作家、正能量，都是他的标签，但不能去定义他，从他的新书中，你能看见更多惊喜。 那些甜甜蜜', '天津人民出版社', '张皓宸', '2018062616432295_2018-06-26_224214.jpg'),
(4, 1, '7', '听你的', 19.40, 12, '从《你是*好的自己》开始，经历《我与世界只差一个你》、《谢谢自己够勇敢》，直到《后来时间都与你有关》，这些年，张皓宸以累积超5,000,000册的销量,成为了90后作家排行榜冠军。 ◆三个月时间，走遍40多个城市，完成超', '天津人民出版社', '张皓宸 ', '2018062616445211_2018-06-26_224154.jpg'),
(6, 1, '5', '老人与海', 23.00, 20, '1、人可以被毁灭，却不可以被战胜。 2、同时获得诺贝尔文学奖、普利策奖，影响历史的百部经典之一。 3、海明威具有代表性的作品，彰显 硬汉形象 。 4、另外附有《太阳照常升起》。 5、随书附赠精美书签1枚。', '时代文艺出版社', '(美)海明威著；张炽恒译', '2018062616575426_2018-06-26_225613.jpg'),
(7, 1, '8', '丰子恺的艺术与人生', 206.30, 10, '一套有人情味的艺术启蒙之书！根据开明书店经典版本重新编辑。看一代民国大家以返璞归真之心，讲述四种融汇中西的艺术故事。  青春正能量 传记每99减50 ', '北京日报出版社（原同心出版社）', '丰子恺 ', '2018062616470310_2018-06-26_224601.jpg'),
(8, 1, '11', '时尚芭莎（全年）', 398.00, 10, '包邮时尚芭莎杂志 时尚娱乐期刊2018年全年杂志订阅新刊预订时尚杂志1年共24期8月起订\r\n高尚审美情趣，深入心灵交流，彰显自我生活', '时尚芭莎杂志', '时尚芭莎杂志', '2018062616592731_2018-06-26_225813.jpg'),
(9, 1, '10', ' 美国金宝贝早教婴幼儿游戏(0-3岁) ', 41.00, 12, '美国金宝贝早教婴幼儿游戏(0-3岁) \r\n \r\n（畅销美国超过13年，早教育儿的绝妙伴侣）  亲子健康美食旅行 点击每99减50>>   \r\n   \r\n作者:〔美〕温蒂玛斯、〔美〕罗尼科恩莱德曼 主编， 栾晓森、史凯 译出版社:北京科学技术出版社出版时间:2016年01月   \r\n在当当育儿/早教榜排名6位    \r\n 19111条评论  ', '北京科学技术出版社', '〔美〕温蒂玛斯', '2018062616523925_2018-06-26_225040.jpg'),
(10, 3, '4', '三体：全三册', 90.00, 10, '三体：全三册 刘慈欣代表作，亚洲首部“雨果奖”获奖作品！相关推荐：三体中的物理学 《三体》的幻想源于经典物理中的三体问题，即三个体积质量相当的天体，在远离其它星系以致其它星系的引力影响可忽略不计的情况下，三个天体在互相引力的作用下互相围绕运行，其运行轨迹将产生不可预测的混沌。很多年来，数学家们一直希望能建立三体乃至多体问题的数学模型，可遗憾的是，得到的结果仅仅是三体问题在非限制条件下的不可解。刘慈欣正是基于这样的科学事实，用大胆的想象和严谨的推断，在三体星系的行星中构建了一个外星文明形态，并描绘了该文明在如同不可捉摸的命运一般的 恒纪元 与 乱纪元 [ 注 1] 的轮替中，数百次的毁灭和重生。三体的故事有着广袤的时间与空间纬度，其以明暗两条线索发展，一条描述了科学家叶文洁在目睹了文革的疯狂与愚昧之后，痛苦的思索着后工业时代对人本¥90.20定价：¥93.00 (9.7折) 当当自营加价购375124条评论刘慈欣 /2010-11-01 /重庆出版社\r\n', '重庆出版社', '刘慈欣', '2018062616483881_2018-06-26_224736.jpg'),
(11, 4, '4', '平凡的世界：全三册', 76.00, 5, '平凡的世界：全三册（八年级下册自主阅读推荐）茅盾文学奖皇冠上的明珠，激励亿万读者的不朽经典。深受老师和学生喜爱的新课标必读书茅盾文学奖皇冠上的明珠 激励亿万读者的不朽经典 深受老师和学生喜爱的新课标必读书 路遥获得了这个世界里数以亿计的普通人的尊敬和崇拜，他沟通了这个世界的人们和地球人类的情感。 陈忠实 他是一个优秀的作家，他是一个出色的政治家，他是一个气势磅礴的人。但他是夸父，倒在干渴的路上。他的文学就像火一样燃出炙人的灿烂的光焰。 贾平凹 对我影响*的人是路遥。是路遥的作品改变了我，让我意识到不放弃总有机会，否则我现在还在蹬三轮车呢。 马 云 作家路遥用毕生心血写就的《平凡的世界》，展示了一幅宏大的普通人在时代大变革中所走过的既平凡又壮美的人生画卷。人生的奋斗，理想的追求，在不同的时代都是相似的。¥74.50定价：¥108.00 (6.9折) 当当自营加价购233033条评论路遥 著 /2017-06-01 /北京十月文艺出版社\r\n', '北京十月文艺出版社', '路遥', '2018062616495039_2018-06-26_224903.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `tblproducttype`
--

DROP TABLE IF EXISTS `tblproducttype`;
CREATE TABLE `tblproducttype` (
  `typeID` int(11) NOT NULL COMMENT '类型编号',
  `typeName` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '类型名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci COMMENT='商品类型表';

--
-- 转存表中的数据 `tblproducttype`
--

INSERT INTO `tblproducttype` (`typeID`, `typeName`) VALUES
(4, '热门小说'),
(5, '世界名著'),
(6, '古典文学'),
(7, '青春文学'),
(8, '名人传记'),
(9, '生活指南'),
(10, '母婴育儿'),
(11, '期刊 /音像');

-- --------------------------------------------------------

--
-- 表的结构 `tblreserve`
--

DROP TABLE IF EXISTS `tblreserve`;
CREATE TABLE `tblreserve` (
  `cartID` int(11) NOT NULL COMMENT '借阅ID',
  `userID` int(11) DEFAULT NULL COMMENT '用户编号',
  `productID` int(11) DEFAULT NULL COMMENT '商品编号',
  `flag` int(11) DEFAULT '1' COMMENT '归还1=借阅2',
  `c_date` datetime DEFAULT NULL COMMENT '借阅时间',
  `u_date` datetime DEFAULT NULL COMMENT '归还时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tblreserve`
--

INSERT INTO `tblreserve` (`cartID`, `userID`, `productID`, `flag`, `c_date`, `u_date`) VALUES
(1, 5, 2, 2, '2020-08-27 07:49:51', '2020-08-29 07:52:55'),
(2, 5, 3, 2, '2020-08-27 07:56:15', '2020-08-29 08:33:13'),
(3, 5, 11, 2, '2020-08-27 09:32:08', '2020-08-28 09:19:14'),
(16, 5, 1, 2, '2020-08-28 09:15:50', '2020-08-28 09:19:05'),
(17, 7, 1, 2, '2020-10-12 08:03:28', '2020-10-30 10:53:51'),
(18, 7, 1, 1, '2020-10-12 08:04:40', '0000-00-00 00:00:00'),
(19, 4, 1, 1, '2021-01-16 12:27:34', '0000-00-00 00:00:00'),
(20, 13, 1, 1, '2022-04-28 21:25:08', NULL),
(21, 13, 1, 1, '2022-04-28 21:26:04', NULL),
(22, 13, 1, 1, '2022-04-28 21:42:06', NULL),
(23, 13, 2, 1, '2022-04-28 21:50:13', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE `tbluser` (
  `uID` int(11) NOT NULL COMMENT '用户编号',
  `uName` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户名称',
  `uPass` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户密码',
  `uKind` int(11) DEFAULT NULL COMMENT '0=普通/1=管理员',
  `address` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '收货地址',
  `card_no` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '身份证号',
  `tel` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '电话'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- 转存表中的数据 `tbluser`
--

INSERT INTO `tbluser` (`uID`, `uName`, `uPass`, `uKind`, `address`, `card_no`, `tel`) VALUES
(2, 'admin', 'admin', 1, '', '', NULL),
(3, '爱德华', '爱德华', 0, '', '', NULL),
(4, '345', '345', 0, '', '', NULL),
(5, '小丽', '111', 0, '2北京市三里屯新貌大廈1208', '210334455662', '13542556543'),
(6, '1', '2', 3, '4', '5', '6'),
(7, '王丽丽', '222', 0, '北京市三里屯新貌大廈1208', '10334455662', '13542556543'),
(9, '999', '999', 0, '2北京市三里屯新貌大廈1208', '210334455662', '135425565434'),
(10, '666', '111', 0, '英国白金汉宫大街129号', '210323198656598789', '13542556543'),
(11, '涵涵1', '1111112', 0, '英国白金汉宫大街129号3', '1111111111111111114', '1354255654345'),
(12, '艾米米', '123', 0, '英国白金汉宫大街129号', '210323198202055489', '13542556543');

--
-- 转储表的索引
--

--
-- 表的索引 `tblcart`
--
ALTER TABLE `tblcart`
  ADD PRIMARY KEY (`cartID`);

--
-- 表的索引 `tblnews`
--
ALTER TABLE `tblnews`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblnotice`
--
ALTER TABLE `tblnotice`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `tblproducts`
--
ALTER TABLE `tblproducts`
  ADD PRIMARY KEY (`productID`);

--
-- 表的索引 `tblproducttype`
--
ALTER TABLE `tblproducttype`
  ADD PRIMARY KEY (`typeID`);

--
-- 表的索引 `tblreserve`
--
ALTER TABLE `tblreserve`
  ADD PRIMARY KEY (`cartID`);

--
-- 表的索引 `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`uID`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `tblcart`
--
ALTER TABLE `tblcart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT COMMENT '借阅ID', AUTO_INCREMENT=32;

--
-- 使用表AUTO_INCREMENT `tblnews`
--
ALTER TABLE `tblnews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `tblnotice`
--
ALTER TABLE `tblnotice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `tblproducts`
--
ALTER TABLE `tblproducts`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品编号', AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `tblproducttype`
--
ALTER TABLE `tblproducttype`
  MODIFY `typeID` int(11) NOT NULL AUTO_INCREMENT COMMENT '类型编号', AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `tblreserve`
--
ALTER TABLE `tblreserve`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT COMMENT '借阅ID', AUTO_INCREMENT=24;

--
-- 使用表AUTO_INCREMENT `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `uID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户编号', AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
