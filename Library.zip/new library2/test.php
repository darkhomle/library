<?php 
require_once './dao/globle.inc.php';
require_once './dao/productsinfoDao.php';
require_once './dao/producttypeDao.php';
require_once './dao/cartDao.php';
require_once './dao/reserveDao.php';

if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	if(!isset($_SESSION["CURRENT_USER"]['uID'])){
		echo "<script> alert('Please login first');parent.location.href='./index.php'; </script>";exit();
	}else{
		$sql="select * from tbluser where uId='{$_SESSION["CURRENT_USER"]['uID']}'";	
		$tbluser = execQueryOne($sql);
		if($tbluser['uKind']==2){
			echo "<script> alert('Your account cannot loan！');parent.location.href='./index.php'; </script>";exit();
		}
	}
	//从表单中读取登录信息
	$userID = $_SESSION["CURRENT_USER"]['uID'];
	$productID = $_POST["productID"];
	$result = addCart($userID,$productID);
	
	if($result){
		$result2 = setPorductNum($productID,0);
		echo "<script> alert('Loan success');parent.location.href='./car2.php'; </script>";
	}
}
if(isset($_POST["act"])&&$_POST["act"]=='ok2'){

	if(!isset($_SESSION["CURRENT_USER"]['uID'])){
		echo "<script> alert('Please login first');parent.location.href='./index.php'; </script>";exit();
	}
	//从表单中读取登录信息
	$userID = $_SESSION["CURRENT_USER"]['uID'];
	$productID = $_POST["productID"];
	$result = addReserve($userID,$productID);
		
		//$result2 = setPorductNum($productID,0);
		echo "<script> alert('Reservation successful');parent.location.href='./car3.php'; </script>";
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
 $(function(){
	 $(".vipNav dd:eq(2)").show();
	 })
</script>
<style>
.search_btn_collect{
width: 80px;
    height: 28px;
    line-height: 28px;
    background: #ffedee;
    color: #ff2832;
    border: 1px solid #ff2832;
    display: inline-block;
    *display: inline;
    zoom: 1;
    border-radius: 3px;
    text-align: center;
    font-family: 'Microsoft Yahei';
    font-size: 14px;
margin-right: 10px;}
</style>
</head>

<body>
 <div class="mianCont">
  <div class="top">
    <?php echo login_top();?><div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="index.php" method="post" class="subBox" name="search" id="search">
    <div class="subBoxDiv">
     <input type="text" name="search" class="subLeft" value="<?php echo $search;?>" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" onclick="('#search').submit();" />
     <div class="hotWord">
      Popular searches: 
      <a href="#"> Children's books</a>&nbsp;
      <a href="#">Masterpieces</a> &nbsp;
      <a href="#">Literature</a>&nbsp;
     </div><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
    
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
     <li><a href="biz/index.php">Add books</a></li>
	 <li><a href="help.php">Help</a></li>
     <div class="clears"></div>
     <div class="phone"><a href="test.php">Book Recognition</a></div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
   Current position: </div><!--positions/-->
  <div class="cont">
   <div class="contLeft" id="contLeft">
    <h3 class="leftTitle">Book Recognition</h3>
    <dl class="helpNav vipNav">
     <dt>Details</dt>
      <dd>
       <a href="user.php">Details</a>
      </dd>
    </dl><!--helpNav/-->
   </div><!--contLeft/-->
   <div class="contRight">
 
   <h2 class="oredrName">
    Book Details
   </h2><form action="" method="post">
   <table class="orderDeatils">
    <tr>
     <td> Select image:
    <input type="file" id="file" name="file" capture="camera" accept="image/jpeg,image/png,image/jpeg,image/gif">
    <p id="result"></p>
    <p id="info"></p>
    <p>Uploaded image:</p>
    <div id="imgDiv" style="display: none;">
        <img id="img" style="height:300px;width: 200px;"/>
    </div>
    <p>Image tested:</p>
    <img id="markImg" style="height:300px;width: 200px;"/>
    <p>Orthodontic images:</p>
    <img id="boxImg" style="height:300px;width: 200px;"/>
    <p>Most Similar Books：</p>
    <img id="targetImg" style="height:300px;width: 200px;"/></td>
    </tr>
   </table> </form>
   </div><!--contRight/-->
   <div class="clears"></div>
  </div><!--cont/-->
  <div class="inHelp"><!--inHLeft/--><!--inHLeft/--><!--inHRight/-->
   <div class="clears"></div>
  </div><!--inHelp/-->
  <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
 

<script>
    //点击选取图片
    $("#file").change(function(event){
        var files = event.target.files, file;
        // 获取目前上传的文件
        file = files[0];
        // 获取 window 的 URL 工具
        var URL = window.URL || window.webkitURL;
        // 通过 file 生成目标 url  获取真实的路径
        var imgURL = URL.createObjectURL(file);
        //用attr将img的src属性改成获得的url
        $("#img").attr("src",imgURL);
        $("#imgDiv").show();
        //发送上传图片的base64
        var base64Pic = '';
        var fileReader = new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload = function(){
             base64Pic = fileReader.result;
             $.ajax({
                    type : 'post',
                    url : 'http://127.0.0.1:8000/bookSearch',
                    data:{'imgBase64':base64Pic},
                    dataType: 'json',
                    success : function(data){
                        $("#markImg").attr("src",data["markImg"]);
                        $("#boxImg").attr("src",data["boxImg"]);
                        $("#targetImg").attr("src",data["targetImg"]);
                        $("#result").html("Matched Books:《"+data["name"]+"》 Similarity:"+data["sim"])
                        
                    }
             });
        }
    });
</script>
</body>
</html>