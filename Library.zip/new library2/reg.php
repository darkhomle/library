<?php 
require_once './dao/userDao.php';
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	//从表单中读取登录信息
	$uName = $_POST["uName"];
	$uPass = $_POST["uPass"];
	$reuPass = $_POST["reuPass"];
	$card_no = $_POST["card_no"];
	$tel = $_POST["tel"];
	$address = $_POST["address"];
	$ukind =0;
	if(empty($uName)){
		echo "<script> alert('Please enter username');parent.location.href='./reg.php'; </script>";exit();
	}elseif(empty($uPass)){
		echo "<script> alert('Please enter password');parent.location.href='./reg.php'; </script>";exit();
	}elseif(empty($reuPass)){
		echo "<script> alert('Please enter confirmation password');parent.location.href='./reg.php'; </script>";exit();
	}elseif($reuPass!=$uPass){
		echo "<script> alert('The password entered twice does not match!');parent.location.href='./reg.php'; </script>";exit();
	}elseif(empty($card_no)){
		echo "<script> alert('ID number cannot be empty');parent.location.href='./reg.php'; </script>";exit();
	}
	//elseif(strlen($card_no)!=18){
	//	echo "<script> alert('ID number must be 18-digit');parent.location.href='./reg.php'; </script>";exit();
	//}
	elseif(empty($tel)){
		echo "<script> alert('Phone number cannot be empty');parent.location.href='./reg.php'; </script>";exit();
	}
	//elseif(strlen($tel)!=11){
	//	echo "<script> alert('Phone number must be 11 digits');parent.location.href='./reg.php'; </script>";exit();
	//}
	elseif(empty($address)){
		echo "<script> alert('Contact address cannot be empty');parent.location.href='./reg.php'; </script>";exit();
	}else{
		
		
		$curUser =  findUserinfoByCard($card_no);
		if($curUser){
			echo "<script> alert('This ID number is registered!');parent.location.href='./reg.php'; </script>";exit();
		}else{
		
			$curUser =  findUserinfoByName($uName);	
			if($curUser){
				echo "<script> alert('This username already exists!');parent.location.href='./reg.php'; </script>";exit();
			}else{
				$ret =  addUserinfo($uName, $uPass, $ukind, $address, $card_no, $tel);
				
				if($ret){
					$curUser =  findUserinfoByNamePwd($uName,$uPass);	
					
					$_SESSION["CURRENT_USER"] = $curUser;
					$_SESSION["CURRENT_USER_OK"] = 1;
					echo "<script> alert('Registration successful');";
					echo "parent.location.href='./index.php'; </script>";
				}else{
					echo "<script> alert('Registration error');";
					echo "parent.location.href='./reg.php'; </script>";
				}
			}
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
	<link rel="stylesheet" href="./biz/style/reset.css" />
	<link rel="stylesheet" href="./biz/style/login.css" />
</head>
<body>
<div class="page">
	<div class="loginwarrp">
	  <div class="login_form"><p style="width:100%;text-align:center;font-size:20px;color:rgb(69, 181, 73);">Sign up</p>
            <form id="Login" name="Login" method="post" onSubmit="" action="">
				<li class="login-item">
					<span>User: </span>
					<input type="text" name="uName" class="login_input">
				</li>
				<li class="login-item">
					<span>PIN:</span>
					<input type="password" name="uPass" class="login_input"></li>
				<li class="login-item">
					<span>CFPIN：</span>	<input type="password" name="reuPass" class="login_input"></li>
				<li class="login-item">
					<span>ID No. :</span>	<input type="text" name="card_no" class="login_input"></li>
				<li class="login-item">
					<span>Phone:</span>	<input type="text" name="tel" class="login_input"></li>
				<li class="login-item">
					<span>Add. ：</span>	<input type="text" name="address" class="login_input"></li>
				<div class="clearfix">
				<li class="login-sub"> 
				<input TYPE="hidden" value="ok" name="act" class="button">
                <input type="submit" name="Submit" value="Submit" />
				<a href="index.php" >[Back to Home]</a>
				</li>
              </div>             
           </form>
		</div>
	</div>
</div>
</body>
</html>