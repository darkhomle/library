<?php 
require_once './dao/globle.inc.php';
require_once './dao/userDao.php';
if(!isset($_SESSION["CURRENT_USER"]['uID'])){
	echo "<script> alert('Please login first');parent.location.href='./index.php'; </script>";
}
if(isset($_POST["act"])&&$_POST["act"]=='ok'){
	
	//从表单中读取登录信息
	$old_pass = $_POST["old_pass"];
	$new_pass = $_POST["new_pass"];
	$renew_pass = $_POST["renew_pass"];
	if(empty($old_pass)){
		echo "<script> alert('Please enter the original password');parent.location.href='./password.php'; </script>";
	}elseif(empty($new_pass)){
		echo "<script> alert('Please enter new password');parent.location.href='./password.php'; </script>";
	}elseif(empty($renew_pass)){
		echo "<script> alert('Please enter confirmation password');parent.location.href='./password.php'; </script>";
	}elseif(empty($renew_pass ==$new_pass)){
		echo "<script> alert('Two incorrect passwords');parent.location.href='./password.php'; </script>";
	}else{
		$result = findUserinfoByuIDPwd($_SESSION["CURRENT_USER"]['uID'],$old_pass);
		if(empty($result)){
			echo "<script> alert('Original password is incorrect');parent.location.href='./password.php'; </script>";
		}else{
			$ret =  updateUserPassword($new_pass,$_SESSION["CURRENT_USER"]['uID']);
			if($ret){
				echo "<script> alert('Modification successful!');";
				echo "parent.location.href='./login.php'; </script>";
			}
		}
	}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
 $(function(){
	 $(".vipNav dd:eq(2)").show();
	 })
</script>
</head>
<body>
 <div class="mianCont">
  <div class="top">
  <?php echo login_top();?>
  <div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="index.php" method="post" class="subBox" name="search" id="search">
    <div class="subBoxDiv">
     <input type="text" name="search" class="subLeft" value="<?php echo $search;?>" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" onclick="('#search').submit();" />
     <div class="hotWord">
      Popular searches: 
      <a href="#"> Children's books</a>&nbsp;
      <a href="#">Masterpieces</a> &nbsp;
      <a href="#">Literature</a>&nbsp;
     </div><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
    
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="password.php">Personal Centre</a></li>
      <li><a href="biz/index.php">Add books</a></li>
	  <li><a href="help.php">Help</a></li>
     <div class="clears"></div>
     <div class="phone"><a href="test.php">Book Recognition</a></div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
  Current position: </div><!--positions/-->
  <div class="cont">
   <div class="contLeft" id="contLeft">
    <h3 class="leftTitle">Personal Centre</h3>
    <dl class="helpNav ">
     <dt><a href="user.php">My homepage</a></dt>
     <dt><a href="password.php">Change password</a></dt>
    </dl>
	<dl class="helpNav ">
     <dt><a href="car.php">My Loans</a></dt>
    </dl><!--helpNav/-->
	<dl class="helpNav ">
     <dt><a href="reserve.php">My Reserves</a></dt>
    </dl><!--helpNav/-->
   </div><!--contLeft/-->
   <div class="contRight">
   <h2 class="oredrName">
    Personal Centre
   </h2>
   <form action="" method="post"/>
   <table class="orderDeatils">
    <tr>
     <th>Original Password</th>
     <td><input type="password" name="old_pass" value=""/></td>
    </tr>
    <tr>
     <th>New Password</th>
     <td><input type="password" name="new_pass" value=""/>
	 </td>
    </tr>
    <tr>
     <th>Confirm Password</th>
     <td><input type="password" name="renew_pass" value=""/>
	 </td>
    </tr>
    <tr>
     <th></th>
     <td>
	 <input TYPE="hidden" value="ok" name="act" class="button">
	 <input type="submit" name="s" value="Modify"/></td>
    </tr>
   </table>  
   </form>
   </div><!--contRight/-->
   <div class="clears"></div>
  </div><!--cont/-->
  <div class="inHelp"><!--inHLeft/--><!--inHLeft/--><!--inHRight/-->
   <div class="clears"></div>
  </div><!--inHelp/-->
 <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
</body>
</html>