<?php 
function ok_info($url,$langinfo){
	if($url==0){
		echo("<script type='text/javascript'> alert('$langinfo');history.go(-1);</script>");		
	}else{
		echo("<script type='text/javascript'> alert('$langinfo'); window.location.href='$url'; </script>");  
	}
	exit;
}
function login_top(){
	if(isset($_SESSION["CURRENT_USER_OK"])&&$_SESSION["CURRENT_USER_OK"]==1){
		 return '<span>Hi！['.$_SESSION["CURRENT_USER"]['uName'].'] Welcome to our library, &nbsp;<a href="loginout.php">[Quit]</a></span></div>';
	}else{
		 return '<span>Hi！[Visitor] Welcome to our library, plese &nbsp;<a href="login.php">[Login]</a>&nbsp;<a href="reg.php">[Sign up]</a></span></div>';
	}
	
}
?>