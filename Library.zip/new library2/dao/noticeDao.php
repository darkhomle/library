<?php
require_once 'dbHelper.php';
//查询所有商品，返回二维数组
function findAllNoticeinfo($search=null){
	if(empty($search)){
		$where  = '1=1';
	}else{
		$where = "name like '%{$search}%'";
	}
	$sql="select * from tblnotice where ".$where.' order by id desc';

	return execQueryAll($sql);
}
//添加
function addNotice($name,$detail,$image=null){
	$up_date = date('Y-m-d H:i:s');
	$sql="INSERT INTO `tblnotice` (`name`, `detail`, `image`, `up_date`) 
		VALUES ('{$name}', '{$detail}', '{$image}', '{$up_date}');";
// echo $sql;
    return execUpdate($sql);
}
//编辑
function updateNotice($id,$name,$detail,$image=null){
	$up_date = date('Y-m-d H:i:s');
	if(!empty($image)){
		$sql="UPDATE `tblnotice` SET `name` = '{$name}'
		, `detail` = '{$detail}'
		, `image` = '{$image}'
		, `up_date` = '{$up_date}' 
		WHERE `tblnotice`.`id` = {$id};";
	}else{
		$sql="UPDATE `tblnotice` SET `name` = '{$name}'
		, `detail` = '{$detail}'
		, `up_date` = '{$up_date}' 
		WHERE `tblnotice`.`id` = {$id};";
	}

    return execUpdate($sql);
}
//删除
function deleteNotice($id){
    $sql="delete from tblnotice where id='$id'";
    return execUpdate($sql);
}
//根据ID查询信息,返回一维数组
function findNoticeById($id){
	$sql="select * from tblnotice where id=$id";
	return execQueryOne($sql);
}
  