<?php
require_once 'dbHelper.php';
//根据用户ID查询借阅信息，返回二维数组 
 function findCartByUId($userID){
    $sql="select *from tblcart where userID='$userID'";
     return execQueryAll($sql);
 }
 function findCarts(){
    $sql="select *from tblcart where 1=1";
     return execQueryAll($sql);
 }
 function findCartById($cartID){
    $sql="select *from tblcart where cartID='$cartID'";
    return execQueryOne($sql);
 }
//添加借阅
function addCart($userID,$productID){
	$c_date = date('Y-m-d H:i:s');
    $sql="INSERT INTO `tblcart` (`userID`, `productID`, `flag`, `c_date`) VALUES ('{$userID}', '{$productID}', '1', '{$c_date}');";
	//echo $sql;exit;
    return execUpdate($sql);
}
//增减库存
function setPorductNum($productID,$type){
	if($type==1){
		$sql="UPDATE `tblproducts` SET `num` = num+1 WHERE `tblproducts`.`productID` = '{$productID}';";
	}else{
		$sql="UPDATE `tblproducts` SET `num` = num-1 WHERE `tblproducts`.`productID` =  '{$productID}';";
	}
	
	return execUpdate($sql);
}
//修改借阅信息
function updateCart($cartID,$userID,$productID,$quantity,$totalprice){
    $sql="update tblCart set userID=$userID,productID=$productID,"
            . "quantity=$quantity,totalprice=$totalprice where cartID=$cartID ";
     return execUpdate($sql);
}
//归还信息
function ReturnCart($cartID){
	$u_date = date('Y-m-d H:i:s');
     $sql="UPDATE `tblcart` SET  `flag` = '2' 
	,	`u_date` = '{$u_date}' 
	 
	 WHERE `tblcart`.`cartID` = '{$cartID}';";
      return execUpdate($sql);
}
//续借信息
function RenewalCart($cartID){
	$u_date = date('Y-m-d H:i:s');
     $sql="UPDATE `tblcart` SET  `flag` = '3' 
	
	 
	 WHERE `tblcart`.`cartID` = '{$cartID}';";
      return execUpdate($sql);
}
//延迟信息
function alertCart($cartID){
	
	$sql="UPDATE `tblcart` SET  c_date = DATE_ADD(c_date,INTERVAL 7 DAY)  WHERE `tblcart`.`cartID` = '{$cartID}';";
	 
    return execUpdate($sql);
}

 function findovertime(){
	
    $sql="select *from tblcart where u_date='0000-00-00 00:00:00'";
	
     return execQueryAll($sql);
 }
