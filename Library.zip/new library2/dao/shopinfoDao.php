<?php 
require_once 'dbHelper.php';
 //查询所有图书，返回二维数组 
    function findAllShopinfo($shopID){
     $sql="select * from tblshopinfo where shopID='$shopID'";
      return execQueryAll($sql);
      }
     
//根据图书名称查询图书信息，返回二维数组
     function findShopinfoByName($shopName){
      $sql="select * from tblshopinfo where shopName=$shopName";
      return execQueryAll($sql);
      }
  //根据图书ID查询图书信息,返回一维数组
     function findShopinfoById($shopID){
     $sql="select * from tblshopinfo where shopID=$shopID";
     return execQueryOne($sql);
     }
    
