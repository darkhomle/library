<?php  
require_once 'dbHelper.php';
//查询所有类型信息，返回一维数组 
function findProductTypeById($typeID){
	$sql="select * from tblproducttype where typeID='$typeID'";
	return execQueryOne($sql);
}
//根据图书名称查询图书信息，返回二维数组
function searchProductTypeByName($typeName){
	$sql="select * from tblproducttype where typeName like '%$typeName%' ";
	return execQueryAll($sql);
}
  
//所有类型信息，返回二维数组
function findProductTypeAll(){
	$sql="select * from tblproducttype where 1=1";

	return execQueryAll($sql);
}
//添加类型名称
function addProductType($typeName){
	$sql="insert into tblproducttype values(null,'$typeName')";
	return execUpdate($sql);
}
//编辑类型名称
function updateProductType($typeName,  $typeID){
    $sql="update tblproducttype set typeName='$typeName' where typeID=$typeID";

    return execUpdate($sql);
}
//删除类型名称
function deleteProductType($typeID){
    $sql="delete from tblproducttype where typeID='$typeID'";
    return execUpdate($sql);
}
     


