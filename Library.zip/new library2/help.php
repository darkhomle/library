<?php 
require_once './dao/globle.inc.php';
require_once './dao/productsinfoDao.php';
require_once './dao/producttypeDao.php';
require_once './dao/cartDao.php';
require_once './dao/newsDao.php';
require_once './dao/reserveDao.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Loan Management System</title>
<link type="text/css" href="css/css.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="js/wb.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
 $(function(){
	 $(".vipNav dd:eq(2)").show();
	 })
</script>
<style>
.search_btn_collect{
width: 80px;
    height: 28px;
    line-height: 28px;
    background: #ffedee;
    color: #ff2832;
    border: 1px solid #ff2832;
    display: inline-block;
    *display: inline;
    zoom: 1;
    border-radius: 3px;
    text-align: center;
    font-family: 'Microsoft Yahei';
    font-size: 14px;
margin-right: 10px;}
</style>
</head>

<body>
 <div class="mianCont">
  <div class="top">
    <?php echo login_top();?><div class="lsg">
   <h1 class="logo"><a href="index.php"><img src="images/logo.png" width="217" height="90" /></a></h1>
   <form action="index.php" method="post" class="subBox" name="search" id="search">
    <div class="subBoxDiv">
     <input type="text" name="search" class="subLeft" value="<?php echo $search;?>" />
     <input type="image" src="images/subimg.png" width="63" height="34" class="sub" onclick="('#search').submit();" />
     <div class="hotWord">
      Popular searches: 
      <a href="#"> Children's books</a>&nbsp;
      <a href="#">Masterpieces</a> &nbsp;
      <a href="#">Literature</a>&nbsp;
     </div><!--hotWord/-->
    </div><!--subBoxDiv/-->
   </form><!--subBox/--><!--gouwuche/-->
  </div><!--lsg/-->
  <div class="pnt">
   <div class="pntLeft">
    <h2 class="Title">All book categories
    
    </h2>
   </div><!--pntLeft/-->
   <div class="pntRight">
    <ul class="nav">
     <li class="navCur"><a href="index.php">Bookstore Home</a></li>
     <li><a href="user.php">Personal Centre</a></li>
     <li><a href="biz/index.php">Add books</a></li>
	 <li><a href="help.php">Help</a></li>
     <div class="clears"></div>
     <div class="phone"><a href="test.php">Book Recognition</a></div>
    </ul><!--nav/-->
   </div><!--pntRight/-->
   <div class="clears"></div>
  </div><!--pnt/-->
  <div class="positions">
   Current position: </div><!--positions/-->
  <div class="cont">
   <div class="contLeft" id="contLeft">
    <h3 class="leftTitle">Book Details</h3>
    <dl class="helpNav vipNav">
     <dt>Details</dt>
      <dd>
       <a href="user.php">Details</a>
      </dd>
    </dl><!--helpNav/-->
   </div><!--contLeft/-->
   <div class="contRight">
  <?php
  $result = findAllnewsinfo();?>
  <form action="" method="post">
   <table class="orderDeatils2">
  
        <?php
        foreach($result as $k=>$row){
		  ?>
          <tr>
            <td align="left"><h2><?php echo $row['name'];?><h2></td>
		  </tr>
		  <tr>
			<td align="left"><?php echo $row['up_date'];?></td>
			  </tr>
		  <tr>
            <td align="left"><img src="./biz/upload/<?php echo $row['image'];?>"  width="300"></td>
		 </tr>
		  <tr>
            <td align="left" style="padding:10px 0;border-bottom:1px solid #f1f1f1"><?php echo $row['detail']; ?>&nbsp;&nbsp;</td>
          </tr>
          <?php
		}
		?>
   </table> </form>
   </div><!--contRight/-->
   <div class="clears"></div>
  </div><!--cont/-->
  <div class="inHelp"><!--inHLeft/--><!--inHLeft/--><!--inHRight/-->
   <div class="clears"></div>
  </div><!--inHelp/-->
  <?php 
require_once './footer.php';
?>
 </div><!--mianCont/-->
 <a href="#" class="backTop">&nbsp;</a>
</body>
</html>